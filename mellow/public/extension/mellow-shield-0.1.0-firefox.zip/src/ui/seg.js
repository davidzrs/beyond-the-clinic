/* Mellow Shield — segmented slider control.
 * The white thumb slides to the chosen option (with a small squash as it lands), reacting at once
 * on click or arrow keys, before the setting is saved. */
(function () {
  const MS = (globalThis.MellowShield = globalThis.MellowShield || {});

  function segmented(box, items, value, onChange) {
    let thumb = box.querySelector('.seg-thumb');
    if (!thumb) { thumb = document.createElement('span'); thumb.className = 'seg-thumb'; box.prepend(thumb); }
    thumb.setAttribute('aria-hidden', 'true');
    box.querySelectorAll('button').forEach((b) => b.remove());
    box.setAttribute('role', 'radiogroup');
    box.style.setProperty('--n', items.length);
    let current = null;

    const buttons = items.map((it, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = it.label;
      b.setAttribute('role', 'radio');
      b.addEventListener('click', () => choose(i));
      b.addEventListener('keydown', (e) => {
        const step = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
        if (!step) return;
        e.preventDefault();
        const next = (i + step + items.length) % items.length;
        choose(next);
        buttons[next].focus();
      });
      box.appendChild(b);
      return b;
    });

    function paint(i, animate) {
      current = items[i].value;
      box.style.setProperty('--i', i);
      buttons.forEach((b, j) => { b.setAttribute('aria-checked', String(j === i)); b.tabIndex = j === i ? 0 : -1; });
      if (animate) { box.classList.remove('is-sliding'); void box.offsetWidth; box.classList.add('is-sliding'); }
    }
    function choose(i) {
      if (items[i].value === current) return;
      paint(i, true);
      onChange(items[i].value);
    }

    // First paint without the slide, so the thumb doesn't fly in from the middle
    box.classList.add('no-anim');
    paint(Math.max(0, items.findIndex((it) => it.value === value)), false);
    requestAnimationFrame(() => requestAnimationFrame(() => box.classList.remove('no-anim')));

    return {
      set(v) {
        const i = items.findIndex((it) => it.value === v);
        if (i >= 0 && v !== current) paint(i, true);
      },
      get value() { return current; },
    };
  }

  MS.ui = { segmented };
})();
