/* Mellow Shield — runs at document_start, before the page draws anything.
 * 1. Blocked sites: the browser's rules already stop them before they load; this catches tabs that were already
 *    open when a site was added to the list, and any browser where those rules are not available.
 * 2. Search pages: pictures start hidden (data-mellow-scan) and only appear once content.js has checked them,
 *    so a heavy picture never flashes on screen before it is covered. */
(function () {
  const api = globalThis.browser || globalThis.chrome;
  if (!api || !api.storage || !api.runtime || window.top !== window) return;
  const host = location.hostname.replace(/^www\./, '').toLowerCase();
  if (!host) return;
  // Injected again (extension installed/updated while the tab was open): only the newest copy acts
  const me = {};
  globalThis.__mellowBlocker = me;
  const current = () => globalThis.__mellowBlocker === me;
  const root = document.documentElement;
  const SEARCH = /(^|\.)(google|bing|duckduckgo|ecosia|startpage|yahoo|yandex|brave|qwant)\./;
  if (SEARCH.test(host) && root) root.setAttribute('data-mellow-scan', '1');

  const matches = (list) => (list || []).find((p) => host === p || host.endsWith('.' + p));
  function check(s) {
    if (!current()) return;
    s = s || {};
    const site = s.enabled !== false && matches(s.blockedSites);
    if (site) { location.replace(api.runtime.getURL('src/blocked/blocked.html') + '?site=' + encodeURIComponent(site) + '&url=' + location.href); return; }
    // switched off or paused here: nothing will check the pictures, so don't hide them
    if (s.enabled === false || matches(s.pausedSites)) root.removeAttribute('data-mellow-scan');
  }
  try {
    api.storage.local.get('ms_settings').then((r) => check(r && r.ms_settings), () => root.removeAttribute('data-mellow-scan'));
    api.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.ms_settings) check(c.ms_settings.newValue); });
  } catch (e) { root.removeAttribute('data-mellow-scan'); }
})();
