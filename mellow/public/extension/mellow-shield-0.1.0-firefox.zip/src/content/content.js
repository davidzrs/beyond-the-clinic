/* Mellow Shield — content script.
 * Finds text blocks on the page, classifies each one (and the whole post it belongs to, for
 * context), and covers heavy ones with a gentle Mellow notice. Never touches what you type. */
(function () {
  const MS = globalThis.MellowShield;
  if (!MS || !document.documentElement) return;
  // Injected again (extension installed/updated while the tab was open): the old copy steps aside
  if (MS.stopContent) { try { MS.stopContent(); } catch (e) { /* old copy already gone */ } }
  let dead = false;
  MS.contentStarted = true;

  const ATTR = 'data-mellow-shield';        // blur | hide | warn
  const REVEALED = 'data-mellow-revealed';
  const HOST = 'mellow-shield-host';
  const SEMANTIC = new Set(['P', 'LI', 'BLOCKQUOTE', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'TD', 'TH', 'DD', 'DT', 'FIGCAPTION', 'PRE', 'CAPTION', 'SUMMARY', 'LEGEND']);
  const BLOCKY = new Set(['P', 'DIV', 'LI', 'UL', 'OL', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'BLOCKQUOTE', 'SECTION', 'ARTICLE', 'TR', 'TD', 'TH', 'DD', 'DT', 'FIGCAPTION', 'PRE', 'HEADER', 'FOOTER']);
  const NO_TEXT = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'SVG', 'MATH', 'CANVAS', 'IFRAME', 'CODE']);
  // Posts and comments are read as a whole too, so cues spread over several lines add up
  // (+ search results: a Google/Bing/DuckDuckGo result or "People also ask" item is judged title + snippet together)
  const POST_SEL = 'article,[role="article"],[data-testid="tweetText"],[data-testid="tweet"],[data-testid="comment"],shreddit-comment,shreddit-post,ytd-comment-renderer,ytd-comment-view-model,div.g,div.MjjYud,.related-question-pair,li.b_algo,[data-testid="result"]';
  const SAFE = 'data-mellow-safe';           // helplines: never covered, nor anything that contains them
  const SKIP_SEL = 'script,style,noscript,template,textarea,input,select,option,code,kbd,samp,svg,math,canvas,iframe,[contenteditable=""],[contenteditable="true"],[contenteditable="plaintext-only"],[role="textbox"],.' + HOST;
  // The whole post around a covered text, whose photos, videos and link cards get covered too
  const MEDIA_POST_SEL = 'article,[role="article"],[data-testid="tweet"],[data-testid="comment"],shreddit-post,shreddit-comment,ytd-comment-renderer,ytd-comment-view-model';
  const POST_ATTR = 'data-mellow-post';      // blur | hide, set on the post so lazy-loaded media is covered too
  const TONE_ATTR = 'data-mellow-tone';      // light | dark, follows the site's own background
  const POS_ATTR = 'data-mellow-pos';        // set when we had to make a block position:relative for the overlay
  const WRAP_ATTR = 'data-mellow-wrap';      // a revealed flex row allowed to wrap, so the "Hide again" row gets its own line
  const MAX_POST = 3000;
  const host = location.hostname.replace(/^www\./, '');

  let settings = null;
  let level = 'balanced';
  let running = false;
  let pageBoost = 1;
  let seen = new WeakMap();              // element -> { len, res }
  const skipCache = new WeakMap();
  const displayCache = new WeakMap();
  const counted = new WeakSet();
  const queue = new Set();
  const roots = new Set();
  let scheduled = false;
  let observer = null;
  let pendingStats = { total: 0, cats: {} };
  let statsTimer = null;

  const idle = (fn) => (globalThis.requestIdleCallback ? requestIdleCallback(fn, { timeout: 700 }) : setTimeout(fn, 60));
  const t = (k, v) => MS.i18n.t(k, v);

  // ---------- finding blocks ----------
  function skipped(el) {
    let v = skipCache.get(el);
    if (v === undefined) { v = !!el.closest(SKIP_SEL); skipCache.set(el, v); }
    return v;
  }
  function isBlock(el) {
    if (SEMANTIC.has(el.tagName)) return true;
    let d = displayCache.get(el);
    if (d === undefined) { d = getComputedStyle(el).display; displayCache.set(el, d); }
    return d !== 'inline' && d !== 'contents' && d !== 'none';
  }
  const isRoot = (el) => !el || el === document.body || el === document.documentElement || el === document.head;
  function blockFor(el) {
    let cur = el;
    for (let i = 0; !isRoot(cur) && i < 12; i++) {
      if (isBlock(cur)) return cur;
      cur = cur.parentElement;
    }
    return isRoot(el) ? null : el; // never the whole page
  }
  const hasWords = (v) => v && v.length >= 6 && /[A-Za-zÀ-ÿ]{2}/.test(v);
  function enqueueText(node) {
    if (!hasWords(node.nodeValue)) return;
    const p = node.parentElement;
    if (!p || skipped(p)) return;
    const b = blockFor(p);
    if (b) queue.add(b);
  }
  // Text of an element without our own notices, with line breaks between blocks
  function textOf(el) {
    const out = [];
    (function walk(node, depth) {
      for (let n = node.firstChild; n; n = n.nextSibling) {
        if (n.nodeType === 3) out.push(n.nodeValue);
        else if (n.tagName === 'IMG') { if (n.alt && onSearchPage()) out.push('\n' + n.alt + '\n'); } // image results are often only an alt text
        else if (n.nodeType === 1) {
          if (NO_TEXT.has(n.tagName) || (n.classList && n.classList.contains(HOST))) continue;
          const b = BLOCKY.has(n.tagName) || n.tagName === 'BR';
          if (b) out.push('\n');
          if (depth < 40) walk(n, depth + 1);
          if (b) out.push('\n');
        }
      }
    })(el, 0);
    return out.join('').replace(/\n{2,}/g, '\n').slice(0, 5000);
  }

  function collect(root) {
    if (!running || !root) return;
    if (root.nodeType === 3) root = root.parentElement;
    if (!root || root.nodeType !== 1 || !root.isConnected) return;
    if (skipped(root)) { seeImgs(root); return; }
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    let budget = 6000;
    while ((n = walker.nextNode()) && budget-- > 0) enqueueText(n);
    // Search pages: pictures are judged by their alt text and caption, as one tile with the picture
    // Every picture is either queued with its tile (and shown once the tile is judged) or shown straight away.
    if (onSearchPage()) {
      const imgs = root.tagName === 'IMG' ? [root] : root.querySelectorAll('img:not([' + SEEN + '])');
      for (const img of imgs) {
        if (img.hasAttribute(SEEN) || skipped(img)) { see(img); continue; }
        const tile = imageTile(img);
        if (tile) { tileOf.set(img, tile); queue.add(tile); }
        else if (!img.complete) { // not loaded yet, so its size is unknown: look again once it has loaded
          img.addEventListener('load', () => { roots.add(img); schedule(); }, { once: true });
          img.addEventListener('error', () => see(img), { once: true });
        } else see(img);
      }
    } else seeImgs(root);
  }

  // Search pages start with their pictures hidden (src/content/blocker.js); a picture is shown once checked
  const SEEN = 'data-mellow-seen';
  const tileOf = new WeakMap();           // picture -> the tile it is judged with
  const see = (img) => img.setAttribute(SEEN, '1');
  const seeImgs = (root) => { if (root.tagName === 'IMG') see(root); else root.querySelectorAll('img:not([' + SEEN + '])').forEach(see); };
  // After a block is judged: show the pictures whose tile it was (if it was heavy, it is covered by now)
  function seeChecked(el) {
    if (el.tagName === 'IMG' || !el.isConnected) return;
    el.querySelectorAll('img:not([' + SEEN + '])').forEach((img) => { const t = tileOf.get(img); if (t && (t === el || !t.isConnected)) see(img); });
  }

  // ---------- pictures on search pages (Google Images, Bing Images, DuckDuckGo…) ----------
  // Social sites have a /search too, but their results are other people's posts, not a search engine's pages:
  // those are judged like any post (searching "kill myself" on X must not unhide the posts that say it)
  const SOCIAL = /(^|\.)(x|twitter|reddit|youtube|tiktok|instagram|facebook|threads|tumblr|bsky|mastodon|discord|linkedin|quora|9gag|imgur)\.(com|net|app|social|gg)$/;
  const socialSite = SOCIAL.test(location.hostname);
  let pageCache = { href: '', search: false, images: false };
  function pageKind() {
    if (pageCache.href === location.href) return pageCache;
    const h = location.hostname;
    const p = new URLSearchParams(location.search);
    const search = !socialSite && (/(^|\.)(google|bing|duckduckgo|ecosia|startpage|yahoo|yandex|brave|qwant)\./.test(h) || /\/(search|images)\b/.test(location.pathname));
    const images = search && (p.get('tbm') === 'isch' || p.get('udm') === '2' || /^\/images\//.test(location.pathname) || p.get('ia') === 'images' || p.get('iax') === 'images' || p.get('t') === 'images');
    pageCache = { href: location.href, search, images };
    return pageCache;
  }
  const onSearchPage = () => pageKind().search;
  function bigImg(img) {
    const r = img.getBoundingClientRect();
    return Math.max(r.width, img.width || 0) >= 48 && Math.max(r.height, img.height || 0) >= 48;
  }
  const bigImgs = (el) => [...el.querySelectorAll('img')].filter(bigImg);
  // The widest box around one picture that holds no other picture (picture + title + source): one tile of the grid
  function imageTile(start) {
    let tile = null;
    for (let cur = start, i = 0; cur && !isRoot(cur) && i < 8; cur = cur.parentElement, i++) {
      if (cur.tagName === 'IMG') { if (bigImg(cur)) tile = cur.parentElement; continue; }
      const n = bigImgs(cur).length;
      if (n > 1 || textOf(cur).length > 600 || cur.matches('[' + SAFE + ']') || cur.querySelector('[' + SAFE + ']')) break;
      if (n === 1) tile = cur;
    }
    return tile && !isRoot(tile) ? tile : null;
  }

  function schedule() {
    if (scheduled || !running) return;
    scheduled = true;
    idle(work);
  }
  function work() {
    scheduled = false;
    const t0 = performance.now();
    for (const r of roots) { roots.delete(r); collect(r); if (performance.now() - t0 > 8) break; }
    for (const el of queue) {
      queue.delete(el);
      if (!el.isConnected) continue;
      evaluate(el);
      seeChecked(el);
      const post = el.parentElement && el.parentElement.closest(POST_SEL);
      if (post && !seen.has(post)) evaluate(post);
      if (performance.now() - t0 > 12) break;
    }
    if (queue.size || roots.size) schedule();
  }

  // What the person searched for, on search engines (their own words are never held against them)
  let queryCache = { href: '', q: '' };
  function searchQuery() {
    if (queryCache.href === location.href) return queryCache.q;
    let q = '';
    if (!socialSite && (/(^|\.)(google|bing|duckduckgo|ecosia|startpage|yahoo|yandex|brave|qwant|search)\./.test(location.hostname) || /\/search\b/.test(location.pathname))) {
      const p = new URLSearchParams(location.search);
      q = p.get('q') || p.get('p') || p.get('text') || p.get('query') || '';
    }
    queryCache = { href: location.href, q };
    return q;
  }

  function options() {
    return { level, categories: settings.categories, customBlock: settings.customBlock, customAllow: settings.customAllow, pageBoost, userQuery: searchQuery() };
  }

  function evaluate(el) {
    if (isRoot(el) || el.tagName === 'MAIN') return;
    // Something the person chose to see ("Show") stays visible: nothing inside it or around it is re-covered
    if (el.closest('[' + REVEALED + ']') || el.querySelector('[' + REVEALED + ']')) return;
    if (el.closest('[' + SAFE + ']')) return; // part of a helpline
    const covered = el.parentElement && el.parentElement.closest('[' + ATTR + ']');
    if (covered) return; // a bigger block around it is already covered
    const text = textOf(el);
    const prev = seen.get(el);
    if (prev && prev.len === text.length) {
      if (prev.res && prev.res.flag && !prev.res.helpline && !el.hasAttribute(ATTR) && !el.querySelector('[' + SAFE + ']')) mark(el, prev.res); // the site re-rendered it
      return;
    }
    const isPost = el.matches(POST_SEL);
    // A post is only covered as a whole when the heaviness comes from context across its lines;
    // if one of its paragraphs is already covered on its own, keep the finer cover.
    const tooBig = text.length > MAX_POST && !SEMANTIC.has(el.tagName); // never cover a whole section of a page
    // A container holding several posts/questions/comments (e.g. "People also ask", a reply thread) is never
    // judged as one block: each item is judged on its own
    const isList = isPost && el.querySelectorAll(POST_SEL).length >= 2;
    // A block whose inner part is already covered is left as it is (no second notice around the first)
    if (text.trim().length < 6 || tooBig || isList || el.querySelector('[' + ATTR + ']')) { seen.set(el, { len: text.length }); return; }
    const res = MS.classify(text, options());
    seen.set(el, { len: text.length, res });
    // Helplines are never covered: mark them so no wider block can swallow them later
    if (res.helpline) { el.setAttribute(SAFE, '1'); if (el.hasAttribute(ATTR)) unmark(el); return; }
    // A bigger block that contains a helpline is never covered as a whole; its parts are judged alone
    if (res.flag && (el.querySelector('[' + SAFE + ']') || (res.mentionsHelpline && !SEMANTIC.has(el.tagName)))) return;
    if (res.flag) mark(coverTarget(el), res);
    else if (el.hasAttribute(ATTR)) unmark(el);
  }

  // One notice per post/result: climb to the widest post container that is still a single item
  // (not a list of posts, not too long, no helpline inside), so title + snippet + media share one cover.
  function coverTarget(el) {
    let target = el;
    let cur = el.parentElement && el.parentElement.closest(POST_SEL);
    while (cur && !isRoot(cur)) {
      if (cur.hasAttribute(SAFE) || cur.querySelector('[' + SAFE + ']')) break;
      const others = [...cur.querySelectorAll(POST_SEL)].filter((p) => !p.contains(target) && !target.contains(p));
      if (others.length) break; // a list of several posts or comments: keep the single one
      const txt = textOf(cur);
      if (txt.length > MAX_POST || MS.classifier.mentionsHelpline(txt)) break;
      target = cur;
      cur = cur.parentElement && cur.parentElement.closest(POST_SEL);
    }
    // Image search: a heavy caption takes its picture with it
    if (pageKind().images && !bigImgs(target).length) {
      const tile = imageTile(target);
      if (tile && tile.contains(target)) target = tile;
    }
    return target;
  }

  // ---------- covering ----------
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  // ---------- matching the site's look ----------
  function parseColor(s) {
    const m = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)/.exec(s || '');
    if (!m) return null;
    const a = m[4] === undefined ? 1 : m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
    return { r: +m[1], g: +m[2], b: +m[3], a };
  }
  const lum = (c) => (0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b) / 255;
  // Background behind the element (first opaque ancestor), so the notice can blend in
  function toneOf(target) {
    for (let cur = target; cur && cur.nodeType === 1; cur = cur.parentElement) {
      const c = parseColor(getComputedStyle(cur).backgroundColor);
      if (c && c.a > 0.6) return { bg: 'rgb(' + c.r + ', ' + c.g + ', ' + c.b + ')', dark: lum(c) < 0.45 };
    }
    const text = parseColor(getComputedStyle(target).color);
    const dark = text ? lum(text) > 0.6 : !!(globalThis.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    return { bg: dark ? 'rgb(21, 24, 30)' : 'rgb(255, 255, 255)', dark };
  }

  // ---------- media of the same post ----------
  const pausingPosts = new WeakSet();
  function postOf(target) {
    const p = target.parentElement && target.parentElement.closest(MEDIA_POST_SEL);
    return p && p !== target ? p : null;
  }
  // Pause videos in a covered area, including autoplaying ones that load later
  function guardVideos(scope, isCovered) {
    scope.querySelectorAll('video').forEach((v) => { try { if (!v.paused) v.pause(); } catch (e) { /* ignore */ } });
    if (pausingPosts.has(scope)) return;
    pausingPosts.add(scope);
    scope.addEventListener('play', (e) => { if (isCovered() && e.target && e.target.pause) e.target.pause(); }, true);
  }
  function coverMedia(target, on) {
    if (on && settings.mode !== 'warn') guardVideos(target, () => target.hasAttribute(ATTR));
    const post = postOf(target);
    if (!post) return;
    if (!on) { post.removeAttribute(POST_ATTR); return; }
    if (settings.mode === 'warn') return;
    post.setAttribute(POST_ATTR, settings.mode);
    guardVideos(post, () => post.hasAttribute(POST_ATTR));
  }

  function buildBanner(target, res, tone) {
    const wrap = el('div', HOST + ' ms-cat-' + res.category + ' ms-sev-' + res.severity + (settings.mode === 'warn' ? ' ms-warn' : '') + (tone.dark ? ' ms-dark' : ''));
    wrap.setAttribute('role', 'note');
    wrap.style.setProperty('--ms-bg', tone.bg);
    const card = el('div', 'ms-card');
    const row = el('div', 'ms-row');
    const face = el('span', 'ms-mallow');
    face.appendChild(MS.art.mallowNode({ face: res.category === 'suicide' ? 'calm' : 'okay', size: 24 }));
    const txt = el('span', 'ms-txt');
    txt.appendChild(el('span', 'ms-title', settings.mode === 'warn' ? t('banner_title_warn') : t('banner_title')));
    txt.appendChild(el('span', 'ms-sub', t('about_' + res.category)));
    const shown = el('span', 'ms-shown', t('shown'));
    txt.appendChild(shown);
    const actions = el('span', 'ms-actions');
    const why = el('button', 'ms-btn ms-ghost', t('why')); why.type = 'button'; why.dataset.ms = 'why'; why.setAttribute('aria-expanded', 'false');
    actions.append(why);
    // "Remove" mode is meant to be final: no way to see the original, only the reason.
    // "Warn" already shows the text. Only "Blur" can be revealed.
    let show = null, hide = null;
    if (settings.mode === 'blur') {
      show = el('button', 'ms-btn ms-ember', t('show')); show.type = 'button'; show.dataset.ms = 'show';
      hide = el('button', 'ms-btn ms-ghost', t('hide_again')); hide.type = 'button'; hide.dataset.ms = 'hide';
      actions.append(show, hide);
    }
    row.append(face, txt, actions);
    card.appendChild(row);

    const reasons = el('span', 'ms-reasons');
    const ex = MS.classifier.explain(res);
    // In "remove" mode the reason is general only: quoting the words would bring the text back.
    const quote = settings.mode !== 'hide';
    ex.tags.slice(0, 4).forEach((r) => {
      const line = el('span', 'ms-reason');
      line.appendChild(el('b', null, t('tag_' + r.t) + (quote ? ': ' : '')));
      if (quote) line.appendChild(document.createTextNode('“' + r.text.slice(0, 60) + '”'));
      reasons.appendChild(line);
    });
    ex.factors.forEach((f) => reasons.appendChild(el('span', 'ms-reason ms-factor', t('ctx_' + f))));
    card.appendChild(reasons);
    if (res.category === 'suicide') card.appendChild(el('span', 'ms-help', t('banner_help')));
    wrap.appendChild(card);

    wrap.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const b = e.target.closest && e.target.closest('[data-ms]');
      if (!b) return;
      if (b.dataset.ms === 'why') { const open = wrap.classList.toggle('ms-open'); why.setAttribute('aria-expanded', String(open)); }
      if (b.dataset.ms === 'show' && show) {
        // The slim "Hide again" row sits above the content. In a single-line flex row (an X post: avatar | text)
        // a full-width row would push the post out of view, so the row is allowed to wrap.
        const cs = getComputedStyle(target);
        if (/flex/.test(cs.display) && !/column/.test(cs.flexDirection) && cs.flexWrap === 'nowrap') target.setAttribute(WRAP_ATTR, '1');
        target.removeAttribute(ATTR); target.setAttribute(REVEALED, '1'); coverMedia(target, false); wrap.classList.add('ms-revealed'); hide.focus(); }
      if (b.dataset.ms === 'hide' && hide) { target.removeAttribute(REVEALED); target.removeAttribute(WRAP_ATTR); target.setAttribute(ATTR, settings.mode); coverMedia(target, true); wrap.classList.remove('ms-revealed'); show.focus(); }
      fitOverlay(wrap);
    }, true);
    ['mousedown', 'pointerdown', 'mouseup', 'pointerup', 'touchstart'].forEach((type) => wrap.addEventListener(type, (e) => e.stopPropagation(), true));
    return wrap;
  }

  // A floating note must stay inside its block: if the card is taller than the block (narrow screens,
  // "Why?" opened on a short post), the block grows instead of the card spilling over its neighbours.
  const origMinH = new WeakMap();
  const fitRO = typeof ResizeObserver === 'function' ? new ResizeObserver((entries) => entries.forEach((e) => fitOverlay(e.target.closest('.' + HOST)))) : null;
  function fitOverlay(banner) {
    if (!banner || !banner.isConnected) return;
    const target = banner.parentElement;
    if (!target) return;
    if (!origMinH.has(target)) origMinH.set(target, target.style.minHeight);
    target.style.minHeight = origMinH.get(target); // measure the block's own height first
    if (!banner.classList.contains('ms-overlay') || banner.classList.contains('ms-revealed')) return;
    const need = banner.querySelector('.ms-card').offsetHeight + 20; // 10px padding above and below
    if (need > target.clientHeight) target.style.setProperty('min-height', need + 'px', 'important');
  }
  function unfit(target) {
    if (origMinH.has(target)) { target.style.minHeight = origMinH.get(target); origMinH.delete(target); }
  }

  function mark(target, res) {
    if (target.closest('[' + REVEALED + ']') || target.querySelector('[' + REVEALED + ']')) return; // revealed by the person
    target.querySelectorAll('[' + ATTR + '],[' + REVEALED + ']').forEach(unmark); // the wider context wins
    const tone = toneOf(target);
    // Blur mode on a tall enough block: the note floats over the blurred content, so it never pushes,
    // squeezes or overlaps the site's own layout (flex rows, grids, Google results…)
    const rect = target.getBoundingClientRect();
    // A picture tile on a search page: a small badge in its corner, over the blurred picture
    const tile = onSearchPage() && rect.width > 0 && rect.width < 520 && bigImgs(target).length === 1 && textOf(target).length < 600;
    const mini = tile || (rect.width > 0 && rect.width < 260); // chips, tags, short links: a tiny badge instead of the full note
    const overlay = !mini && settings.mode === 'blur' && rect.height >= 96;
    if ((overlay || tile) && getComputedStyle(target).position === 'static') target.setAttribute(POS_ATTR, '1');
    target.setAttribute(TONE_ATTR, tone.dark ? 'dark' : 'light');
    target.setAttribute(ATTR, settings.mode);
    coverMedia(target, true);
    let banner = null;
    for (const c of target.children) if (c.classList.contains(HOST)) banner = c;
    if (!banner) {
      banner = buildBanner(target, res, tone);
      if (overlay) banner.classList.add('ms-overlay');
      if (tile) banner.classList.add('ms-tile');
      if (mini) { banner.classList.add('ms-mini'); banner.title = t(settings.mode === 'warn' ? 'banner_title_warn' : 'banner_title') + ' · ' + t('about_' + res.category); }
      target.insertBefore(banner, target.firstChild);
      if (overlay) { if (fitRO) fitRO.observe(banner.querySelector('.ms-card')); requestAnimationFrame(() => fitOverlay(banner)); }
    }
    if (!counted.has(target)) {
      counted.add(target);
      pendingStats.total += 1;
      pendingStats.cats[res.category] = (pendingStats.cats[res.category] || 0) + 1;
      clearTimeout(statsTimer);
      statsTimer = setTimeout(flushStats, 1500);
    }
  }
  function unmark(target) {
    target.removeAttribute(ATTR);
    target.removeAttribute(REVEALED);
    target.removeAttribute(TONE_ATTR);
    target.removeAttribute(POS_ATTR);
    target.removeAttribute(WRAP_ATTR);
    unfit(target);
    for (const c of [...target.children]) if (c.classList.contains(HOST)) { if (fitRO) { const card = c.querySelector('.ms-card'); if (card) fitRO.unobserve(card); } c.remove(); }
    const post = postOf(target);
    if (post && !post.querySelector('[' + ATTR + ']')) post.removeAttribute(POST_ATTR);
  }
  function unmarkAll() {
    document.querySelectorAll('[' + ATTR + '],[' + REVEALED + ']').forEach(unmark);
    document.querySelectorAll('.' + HOST).forEach((b) => b.remove());
    document.querySelectorAll('[' + POST_ATTR + ']').forEach((p) => p.removeAttribute(POST_ATTR));
  }
  function flushStats() {
    if (!pendingStats.total) return;
    const delta = pendingStats;
    pendingStats = { total: 0, cats: {} };
    MS.settings.addStats(delta).catch(() => {});
  }

  // ---------- lifecycle ----------
  function onMutations(list) {
    for (const m of list) {
      if (m.type === 'characterData') { enqueueText(m.target); continue; }
      if (m.type === 'attributes') { if (m.target.tagName === 'IMG' && onSearchPage()) roots.add(m.target); continue; } // a lazy picture got its alt/size
      m.addedNodes.forEach((n) => {
        if (n.nodeType === 1 && n.classList && n.classList.contains(HOST)) return;
        if (n.nodeType === 1 || n.nodeType === 3) roots.add(n);
      });
    }
    schedule();
  }

  function computePageBoost() {
    // A page whose title is itself about suicide methods or "pro" content lowers the thresholds a little
    const meta = document.querySelector('meta[name="description"]');
    const head = (document.title || '') + '. ' + ((meta && meta.content) || '');
    const r = MS.classify(head, { level: 'protective' });
    pageBoost = r.scores.suicide >= 2.4 && !r.factors.includes('protective') && !r.factors.includes('education') ? 0.85 : 1;
  }

  // Nothing will check the pictures here: stop hiding them
  const unscan = () => document.documentElement.removeAttribute('data-mellow-scan');

  function stop() {
    running = false;
    if (observer) { observer.disconnect(); observer = null; }
    queue.clear();
    roots.clear();
    unmarkAll();
  }

  // Lets pages (e.g. the test pages) see whether Mellow Shield is running here: on | off | paused | error
  const announce = (state) => { try { document.documentElement.setAttribute('data-mellow-shield-active', state); } catch (e) { /* ignore */ } };

  async function start() {
    try { settings = await MS.settings.load(); } catch (e) { announce('error'); unscan(); return; }
    MS.i18n.setLang(settings.lang);
    level = MS.settings.effectiveLevel(settings).level;
    if (!settings.enabled || MS.settings.isPaused(settings, host)) { stop(); announce(settings.enabled ? 'paused' : 'off'); unscan(); return; }
    if (!onSearchPage()) unscan();
    announce('on');
    running = true;
    if (!document.body) { document.addEventListener('DOMContentLoaded', start, { once: true }); return; }
    computePageBoost();
    roots.add(document.body);
    schedule();
    if (!observer) {
      observer = new MutationObserver(onMutations);
      observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['alt', 'src'] });
    }
  }

  MS.stopContent = () => { dead = true; stop(); };
  MS.store.onChange((changes) => {
    if (dead || !changes.ms_settings) return;
    stop();
    seen = new WeakMap();
    start();
  });
  start();
})();
