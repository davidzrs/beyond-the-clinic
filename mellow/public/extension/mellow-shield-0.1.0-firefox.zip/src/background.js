/* Mellow Shield — background.
 * 1. Keeps the browser's own blocking rules (declarativeNetRequest) in step with the "Blocked sites" list,
 *    so a blocked site never even loads: the browser opens the calm Mellow page instead.
 * 2. Applies changes to tabs that are already open, with no reload: blocking a site (or switching the
 *    extension on) turns its open tabs into the Mellow page; unblocking it (or switching the extension off)
 *    takes those tabs back to the address that was asked for.
 * 3. On install/update, puts the content scripts into tabs that were already open, so they work at once. */
const api = globalThis.browser || globalThis.chrome;
const BLOCK_PAGE = 'src/blocked/blocked.html';
const pageURL = () => api.runtime.getURL(BLOCK_PAGE);
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

async function load() { const r = await api.storage.local.get('ms_settings'); return r.ms_settings || {}; }
const activeList = (s) => (s.enabled === false ? [] : [...new Set((s.blockedSites || []).filter(Boolean))].slice(0, 500));
const hostOf = (url) => { try { const u = new URL(url); return /^https?:$/.test(u.protocol) ? u.hostname.replace(/^www\./, '').toLowerCase() : ''; } catch (e) { return ''; } };
const blockedFor = (sites, host) => !!host && sites.find((p) => host === p || host.endsWith('.' + p));

async function syncRules(sites) {
  if (!api.declarativeNetRequest) return;
  const old = await api.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = old.map((x) => x.id);
  // The address that was asked for goes along (last, as "&url=..."), so the Mellow page can go back to it
  const addRules = sites.map((site, i) => ({
    id: i + 1,
    priority: 1,
    action: { type: 'redirect', redirect: { regexSubstitution: pageURL() + '?site=' + encodeURIComponent(site) + '&url=\\0' } },
    condition: { regexFilter: '^https?://([^/?#]*\\.)?' + esc(site) + '([:/?#].*)?$', resourceTypes: ['main_frame'] },
  }));
  try {
    await api.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  } catch (e) {
    // A browser that refuses the regex rules still gets plain ones (without the address that was asked for)
    const plain = sites.map((site, i) => ({
      id: i + 1,
      priority: 1,
      action: { type: 'redirect', redirect: { extensionPath: '/' + BLOCK_PAGE + '?site=' + encodeURIComponent(site) + '&' } },
      condition: { requestDomains: [site], resourceTypes: ['main_frame'] },
    }));
    await api.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: plain });
  }
}

// The address saved on a Mellow page ("...&url=https://..."), only if it belongs to the blocked site
function askedURL(tabURL, site) {
  const i = tabURL.indexOf('&url=');
  const raw = i >= 0 ? tabURL.slice(i + 5) : '';
  const h = hostOf(raw);
  return h && (h === site || h.endsWith('.' + site)) ? raw : 'https://' + site + '/';
}

async function syncTabs(sites) {
  if (!api.tabs) return;
  const page = pageURL();
  const tabs = await api.tabs.query({});
  for (const tab of tabs) {
    const url = tab.url || tab.pendingUrl || '';
    if (!url) continue;
    try {
      if (url.startsWith(page)) {
        const site = new URL(url).searchParams.get('site') || '';
        if (site && !blockedFor(sites, site)) await api.tabs.update(tab.id, { url: askedURL(url, site) });
      } else {
        const site = blockedFor(sites, hostOf(url));
        if (site) await api.tabs.update(tab.id, { url: page + '?site=' + encodeURIComponent(site) + '&url=' + url });
      }
    } catch (e) { /* tab closed meanwhile */ }
  }
}

let running = Promise.resolve();
let lastKey = null;
function sync(force) {
  running = running.then(async () => {
    const sites = activeList(await load());
    const key = JSON.stringify(sites);
    if (!force && key === lastKey) return; // something else in the settings changed
    lastKey = key;
    await syncRules(sites); // rules first, so a tab sent back to its site isn't redirected here again
    await syncTabs(sites);
  }).catch((e) => console.warn('Mellow Shield: could not update blocked sites', e));
  return running;
}

// Content scripts for tabs that were open before the extension was installed or updated
async function injectOpenTabs() {
  if (!api.scripting || !api.tabs) return;
  const m = api.runtime.getManifest();
  const tabs = await api.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const tab of tabs) {
    for (const cs of m.content_scripts || []) {
      try {
        if (cs.css) await api.scripting.insertCSS({ target: { tabId: tab.id }, files: cs.css });
        if (cs.js) await api.scripting.executeScript({ target: { tabId: tab.id }, files: cs.js });
      } catch (e) { /* pages the extension can't touch (store, settings…) */ }
    }
  }
}

api.runtime.onInstalled.addListener(() => { sync(true); injectOpenTabs(); });
if (api.runtime.onStartup) api.runtime.onStartup.addListener(() => sync(true));
api.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.ms_settings) sync(false); });
sync(true);
