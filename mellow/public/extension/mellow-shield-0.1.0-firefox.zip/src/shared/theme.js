/* Mellow Shield — day / night theme, like the Mellow app: it follows the clock (7:00–19:00 is day),
 * and the sun/moon button flips it until the clock changes it again. */
(function () {
  const MS = (globalThis.MellowShield = globalThis.MellowShield || {});
  const isDayHour = (d) => d.getHours() >= 7 && d.getHours() < 19;
  const autoMode = (d) => (isDayHour(d || new Date()) ? 'day' : 'night');
  // An id for the current day/night stretch, so an override only lasts until the next switch
  function period(d) {
    d = d || new Date();
    const n = new Date(d);
    if (d.getHours() < 7) n.setDate(n.getDate() - 1); // after midnight still belongs to last night
    return n.toISOString().slice(0, 10) + (isDayHour(d) ? 'd' : 'n');
  }
  function resolve(settings) {
    const o = settings && settings.themeOverride;
    return o && o.period === period() ? o.mode : autoMode();
  }
  function apply(mode) { document.documentElement.setAttribute('data-theme', mode); return mode; }
  function flip(settings) {
    const next = resolve(settings) === 'day' ? 'night' : 'day';
    return { mode: next, period: period() };
  }
  MS.theme = { autoMode, period, resolve, apply, flip };
})();
