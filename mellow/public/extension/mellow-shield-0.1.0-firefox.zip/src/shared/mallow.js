/* Mellow Shield — the Mellow app's own pixel art (marshmallow + icons), ported from
 * mellow/src/pixel/sprites.ts so the extension looks like the app. Drawn as crisp SVG, no images. */
(function () {
  const MS = (globalThis.MellowShield = globalThis.MellowShield || {});

  const OL = '#2a2038';
  const W = '#ffffff';
  const COLORS = {
    vanilla: { base: '#f4ead8', light: '#fffaf0', shade: '#d6c6ae' },
    strawberry: { base: '#f3c5cf', light: '#fde3e8', shade: '#d79aaa' },
    mint: { base: '#cbe6cf', light: '#e8f6ea', shade: '#9fc6a8' },
    lavender: { base: '#d8cdef', light: '#efe9fb', shade: '#ad9fd2' },
    toasted: { base: '#ebc28e', light: '#f7dcb2', shade: '#c4935c' },
    blueberry: { base: '#bfd3ef', light: '#e0ebfa', shade: '#8faad3' },
  };

  function Cv() {
    const m = new Map();
    return {
      m,
      set(x, y, c) { m.set(x + ',' + y, c); },
      rect(x, y, w, h, c) { for (let i = 0; i < w; i++) for (let j = 0; j < h; j++) m.set((x + i) + ',' + (y + j), c); },
      pts(a, c) { a.forEach(([x, y]) => m.set(x + ',' + y, c)); },
    };
  }
  function outlined(v) {
    const o = new Map();
    for (const k of v.m.keys()) {
      const [x, y] = k.split(',').map(Number);
      [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dx, dy]) => { const kk = (x + dx) + ',' + (y + dy); if (!v.m.has(kk)) o.set(kk, OL); });
    }
    for (const [k, c] of v.m) o.set(k, c);
    return o;
  }

  // Faces exactly as in the app
  const FACES = {
    content: (v) => { v.rect(12, 17, 2, 2, OL); v.rect(18, 17, 2, 2, OL); v.set(12, 17, W); v.set(18, 17, W); v.pts([[14, 20], [17, 20], [15, 21], [16, 21]], OL); },
    happy: (v) => { v.pts([[11, 18], [12, 17], [13, 17], [14, 18], [17, 18], [18, 17], [19, 17], [20, 18]], OL); v.pts([[14, 20], [17, 20], [15, 21], [16, 21]], OL); },
    excited: (v) => { v.rect(12, 16, 2, 3, OL); v.rect(18, 16, 2, 3, OL); v.set(12, 16, W); v.set(18, 16, W); v.rect(14, 20, 4, 1, OL); v.pts([[14, 21], [17, 21]], OL); v.rect(15, 21, 2, 1, '#e86a7a'); v.rect(15, 22, 2, 1, OL); },
    calm: (v) => { v.pts([[11, 17], [12, 18], [13, 18], [14, 17], [17, 17], [18, 18], [19, 18], [20, 17]], OL); v.pts([[15, 21], [16, 21]], OL); },
    okay: (v) => { v.rect(12, 17, 2, 2, OL); v.rect(18, 17, 2, 2, OL); v.set(12, 17, W); v.set(18, 17, W); v.pts([[15, 21], [16, 21]], OL); },
    tired: (v) => { v.pts([[12, 18], [13, 18], [18, 18], [19, 18]], OL); v.pts([[12, 17], [13, 17], [18, 17], [19, 17]], 'rgba(42,32,56,.35)'); v.pts([[15, 21], [16, 21]], OL); },
    heavy: (v) => { v.pts([[12, 18], [13, 18], [18, 18], [19, 18]], OL); v.pts([[11, 16], [12, 16], [19, 16], [20, 16]], 'rgba(42,32,56,.45)'); v.pts([[14, 21], [15, 20], [16, 20], [17, 21]], OL); },
  };
  // The app's mood -> face mapping
  const MOOD_FACE = { heavy: 'heavy', low: 'tired', okay: 'okay', good: 'content', bright: 'happy' };

  const cache = new Map();
  function mallowPixels(color, face) {
    const key = color + '|' + face;
    if (cache.has(key)) return cache.get(key);
    const out = new Map();
    const sh = Cv(); sh.rect(9, 29, 14, 1, 'rgba(0,0,0,.28)'); sh.rect(11, 30, 10, 1, 'rgba(0,0,0,.18)');
    const c = COLORS[color] || COLORS.vanilla;
    const b = Cv();
    for (let x = 8; x <= 23; x++) for (let y = 11; y <= 28; y++) {
      const dx = Math.min(x - 8, 23 - x), dy = Math.min(y - 11, 28 - y);
      if (dx + dy < 2) continue;
      let k = c.base;
      if (y <= 12) k = c.light; else if (y === 13) k = c.shade; else if (x >= 22 || y >= 27) k = c.shade; else if (x === 9 && y <= 23) k = c.light;
      b.set(x, y, k);
    }
    b.set(10, 15, c.light); b.set(10, 16, c.light);
    const ch = Cv(); ch.pts([[10, 20], [11, 20], [20, 20], [21, 20]], '#f2939b');
    const f = Cv(); (FACES[face] || FACES.content)(f);
    [sh.m, outlined(b), ch.m, f.m].forEach((m) => { for (const [k, v] of m) out.set(k, v); });
    cache.set(key, out);
    return out;
  }

  // The app's 10 x 10 icons
  const IP = { y: '#ffc66b', Y: '#f0913a', g: '#86c094', G: '#3f7a5a', c: '#f4ead5', d: '#b8b2cc', p: '#e88a96', b: '#8fb4e6', B: '#4f74b8', v: '#a595d4', V: '#6b5b9a', R: '#c8564a', k: '#6a6888', K: '#4a4866', w: '#ffffff', n: '#7a4e30' };
  const ICONS = {
    home: ['....RR....', '...RRRR...', '..RRRRRR..', '.RRRRRRRR.', 'RRRRRRRRRR', '.cccccccc.', '.ccnncyyc.', '.ccnncyyc.', '.ccnncccc.', '.cccccccc.'],
    flame: ['....Y.....', '...YY.....', '...YYY.Y..', '..YYyYYY..', '..YyyyYY..', '.YYyycyY..', '.YyyccyY..', '..YyyyY...', '.nnnnnnn..', '..n...n...'],
    leaf: ['......gggg', '....gggggg', '...ggGgggg', '..ggGggggg', '..gGggggg.', '..Gggggg..', '.G.gggg...', 'G.........', '..........', '..........'],
    sun: ['....y.....', '.y..y..y..', '..yyyyy...', '.yyYYYyy..', 'yyYYYYYyy.', '.yyYYYyy..', '..yyyyy...', '.y..y..y..', '....y.....', '..........'],
    moon: ['...yyy....', '..yy......', '.yy.......', '.yy.......', '.yy.......', '.yyy......', '..yyyy.yy.', '...yyyyy..', '..........', '..........'],
    chat: ['.cccccccc.', 'cccccccccc', 'ccVccVccVc', 'cccccccccc', '.cccccccc.', '..cc......', '.cc.......', '..........', '..........', '..........'],
    note: ['cccccccccc', 'cVcccccccV', 'ccVccccVcc', 'cccVccVccc', 'ccccVVcccc', 'cccccccccc', 'cccccccccc', '..........', '..........', '..........'],
    tree: ['....G.....', '...GgG....', '..GgggG...', '...GgG....', '..GgggG...', '.GgggggG..', 'GgggggggG.', '....n.....', '....n.....', '..........'],
    wave: ['..........', '..bb......', '.b..b..bb.', 'b....bb..b', '..........', '..BB......', '.B..B..BB.', 'B....BB..B', '..........', '..........'],
  };
  function iconPixels(name, color) {
    const rows = ICONS[name] || ICONS.flame;
    const out = new Map();
    rows.forEach((row, y) => [...row].forEach((ch, x) => { if (ch !== '.') out.set(x + ',' + y, color && ch !== 'c' && ch !== 'w' ? color : IP[ch]); }));
    return out;
  }

  // Pixels -> horizontal runs -> SVG (string, or DOM nodes for pages that forbid innerHTML)
  function runs(pixels) {
    const byRow = new Map();
    for (const [k, c] of pixels) { const [x, y] = k.split(',').map(Number); if (!byRow.has(y)) byRow.set(y, []); byRow.get(y).push([x, c]); }
    const out = [];
    for (const [y, cells] of byRow) {
      cells.sort((a, b) => a[0] - b[0]);
      let i = 0;
      while (i < cells.length) {
        let j = i;
        while (j + 1 < cells.length && cells[j + 1][0] === cells[j][0] + 1 && cells[j + 1][1] === cells[i][1]) j++;
        out.push({ x: cells[i][0], y, w: j - i + 1, fill: cells[i][1] });
        i = j + 1;
      }
    }
    return out;
  }
  function svgString(pixels, box, size, label) {
    const rects = runs(pixels).map((r) => '<rect x="' + r.x + '" y="' + r.y + '" width="' + r.w + '" height="1" fill="' + r.fill + '"/>').join('');
    const aria = label ? ' role="img" aria-label="' + label + '"' : ' aria-hidden="true"';
    const h = Math.round((size * box[3]) / box[2]);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + box.join(' ') + '" width="' + size + '" height="' + h + '" shape-rendering="crispEdges"' + aria + '>' + rects + '</svg>';
  }
  function svgNode(pixels, box, size) {
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', box.join(' '));
    svg.setAttribute('width', String(size));
    svg.setAttribute('height', String(Math.round((size * box[3]) / box[2])));
    svg.setAttribute('shape-rendering', 'crispEdges');
    svg.setAttribute('aria-hidden', 'true');
    runs(pixels).forEach((r) => {
      const rect = document.createElementNS(NS, 'rect');
      rect.setAttribute('x', r.x); rect.setAttribute('y', r.y); rect.setAttribute('width', r.w); rect.setAttribute('height', 1); rect.setAttribute('fill', r.fill);
      svg.appendChild(rect);
    });
    return svg;
  }

  const MALLOW_BOX = [6, 9, 20, 23]; // the marshmallow and its shadow, cropped from the 32 x 32 canvas
  const ICON_BOX = [0, 0, 10, 10];
  const mallowSVG = (o) => { o = o || {}; return svgString(mallowPixels(o.color || 'vanilla', o.face || 'content'), MALLOW_BOX, o.size || 40, o.label); };
  const mallowNode = (o) => { o = o || {}; return svgNode(mallowPixels(o.color || 'vanilla', o.face || 'content'), MALLOW_BOX, o.size || 40); };
  const iconSVG = (name, o) => { o = o || {}; return svgString(iconPixels(name, o.color), ICON_BOX, o.size || 20, o.label); };
  const flameSVG = (o) => iconSVG('flame', o);

  MS.art = { mallowSVG, mallowNode, iconSVG, flameSVG, MOOD_FACE, mallowPixels, iconPixels };
})();
