/*
 * Mellow Shield — context-aware classifier. Runs fully on the device.
 *
 * 1. Normalise (accents, case, leetspeak, "s u i c i d e", "s*icide").
 * 2. Per sentence: blank out idioms, objects that "die" and negations, then match triggers.
 *    Generic phrases weigh more in the first person; suicide cues weigh more with "tonight/now";
 *    hyperbolic phrases weigh less next to laughter.
 * 3. Per block: combine sentences (strongest + 1/2 second + 1/4 rest), add cluster bonuses
 *    (farewell + hopelessness, method + ideation, several weak cues) so indirect messages are
 *    not missed, then apply context reducers (help resources, recovery stories, fiction,
 *    information, happy goodbyes).
 * 4. Compare each enabled category with the threshold for the chosen protection level.
 */
(function () {
  const MS = (globalThis.MellowShield = globalThis.MellowShield || {});
  const L = MS.lexicon;

  const THRESHOLDS = { gentle: 3.2, balanced: 2.4, protective: 1.6 };
  const CAT_FACTOR = { suicide: 0.9, hostile: 1, hopeless: 1, selfworth: 1, news: 1, custom: 1 };
  const CATS = ['suicide', 'hostile', 'hopeless', 'selfworth', 'news', 'custom'];
  const DISTRESS = ['suicide', 'hopeless', 'selfworth'];

  const PREFILTER = new RegExp(L.TRIGGERS.map((t) => '(?:' + t.r.source + ')').join('|'));
  const ECHO = new Set(L.ECHO_TAGS);
  const HELPLINE_MAX = 700; // a block this short that names a helpline with a number IS the helpline

  // A helpline is a named line (or a "help is available" header) together with a number
  function helplineSignals(norm) {
    const name = L.HELPLINE.name.test(norm);
    const head = L.HELPLINE.head.test(norm);
    const phone = L.HELPLINE.phone.test(norm);
    return (name && (phone || head)) || (head && phone);
  }

  const count = (re, s) => { re.lastIndex = 0; const m = s.match(re); return m ? m.length : 0; };
  const has = (re, s) => count(re, s) > 0;
  const round = (v) => Math.round(v * 100) / 100;
  const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // One word of the person's own lists, in singular or plural (PT and EN), already without accents/capitals:
  // cafe -> cafes, flor -> flores, animal -> animais, homem -> homens, pao -> paes/paos/poes, party -> parties
  function pluralWord(w) {
    const e = escapeRe(w);
    if (w.length < 3 || !/[a-z]$/.test(w)) return e;
    const alts = ['s', 'es'];
    if (/m$/.test(w)) alts.push(escapeRe(w.slice(0, -1)) + 'ns');
    if (/[aeou]l$/.test(w)) alts.push(escapeRe(w.slice(0, -1)) + 'is');
    if (/il$/.test(w)) alts.push(escapeRe(w.slice(0, -1)) + 's', escapeRe(w.slice(0, -2)) + 'eis');
    if (/ao$/.test(w)) alts.push(escapeRe(w.slice(0, -2)) + 'oes', escapeRe(w.slice(0, -2)) + 'aes');
    if (/[^aeiou]y$/.test(w)) alts.push(escapeRe(w.slice(0, -1)) + 'ies');
    if (/(s|z|x|r)$/.test(w)) alts.push('es');
    // typed in the plural: the singular counts too ("cafes" -> "cafe", "flores" -> "flor")
    if (w.length > 4 && /[^s]s$/.test(w)) alts.push(escapeRe(w.slice(0, -1)));
    if (w.length > 5 && /[rzs]es$/.test(w)) alts.push(escapeRe(w.slice(0, -2)));
    // the stem-changing plurals replace the whole word; the rest are endings
    const endings = alts.filter((a) => a === 's' || a === 'es');
    const whole = alts.filter((a) => a !== 's' && a !== 'es');
    return '(?:' + e + '(?:' + [...new Set(endings)].join('|') + ')?' + (whole.length ? '|' + whole.join('|') : '') + ')';
  }
  // A whole word or phrase from the lists; each word may be plural ("cafe" also hides "cafes", "Cafés")
  const listRe = (phrase, flags) => new RegExp('\\b' + phrase.split(/\s+/).map(pluralWord).join('\\s+') + '\\b', flags);

  function deobfuscate(s) {
    // Spaced or dotted letters: "s u i c i d e", "k.i.l.l"
    s = s.replace(/\b(?:[a-z][ .\-_*]){3,}[a-z]\b/g, (m) => {
      const j = m.replace(/[ .\-_*]/g, '');
      if (L.COMPOUNDS[j]) return L.COMPOUNDS[j];
      return L.SENSITIVE_WORDS.some((w) => j === w || j.includes(w)) ? j : m;
    });
    // Censored words: "s*icide", "k**l", "m*rrer"
    s = s.replace(/[a-z]*\*+[a-z*]*/g, (tok) => {
      const letters = tok.replace(/\*/g, '');
      if (letters.length < 2) return tok;
      const re = new RegExp('^' + tok.replace(/\*/g, '[a-z]') + '$');
      const hit = L.SENSITIVE_WORDS.find((w) => re.test(w));
      return hit || tok;
    });
    return s;
  }

  function normalize(raw) {
    let s = String(raw || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase();
    s = s.replace(/[​-‍⁠﻿]/g, '').replace(/[’‘`´]/g, "'").replace(/ /g, ' ');
    // Leetspeak only inside tokens that mix letters and digits: "k1ll" -> "kill", "su1c1de" -> "suicide"
    s = s.replace(/[a-z0-9@$]+/g, (w) => (/[a-z]/.test(w) && /[0-9@$]/.test(w)
      ? w.replace(/0/g, 'o').replace(/1/g, 'i').replace(/3/g, 'e').replace(/4/g, 'a').replace(/5/g, 's').replace(/7/g, 't').replace(/@/g, 'a').replace(/\$/g, 's')
      : w));
    s = deobfuscate(s);
    s = s.replace(/([a-z])-([a-z])/g, '$1 $2').replace(/([a-z])-([a-z])/g, '$1 $2'); // matar-me -> matar me
    s = s.replace(/([a-z])\1{2,}/g, '$1$1'); // "morrerrrr" -> "morrerr", "soooo" -> "soo"
    s = s.replace(/[ \t]+/g, ' ');
    return s;
  }

  function splitSentences(s) {
    return s.split(/(?<=[.!?…;])\s+|\n+|\s[–—-]\s/).map((x) => x.trim()).filter(Boolean);
  }

  function maskAll(sentence, masks, ignored) {
    let out = sentence;
    for (const m of masks) {
      m.r.lastIndex = 0;
      out = out.replace(m.r, (match) => { ignored.push({ t: m.t, text: match.trim() }); return ' '.repeat(match.length); });
    }
    return out;
  }

  function classify(text, opts) {
    opts = opts || {};
    const level = THRESHOLDS[opts.level] ? opts.level : 'balanced';
    const enabled = Object.assign({ suicide: true, hopeless: true, selfworth: true, hostile: true, news: false }, opts.categories || {});
    const customBlock = (opts.customBlock || []).map((w) => normalize(w).trim()).filter(Boolean);
    const customAllow = (opts.customAllow || []).map((w) => normalize(w).trim()).filter(Boolean);
    const norm = normalize(String(text || '').slice(0, 4000));

    const result = { flag: false, category: null, score: 0, threshold: 0, severity: null, scores: {}, hits: [], ignored: [], factors: [], normalized: norm, original: String(text || '').slice(0, 4000), helpline: false, mentionsHelpline: false };
    CATS.forEach((c) => { result.scores[c] = 0; });
    // On a search page, the words the person typed are theirs, not something to hide from them
    const query = opts.userQuery ? normalize(opts.userQuery).trim() : '';
    const isEcho = (s) => query.length >= 4 && (query.includes(s) || (s.includes(query) && s.length - query.length <= 12));
    // Same topic word in another form or language: searched "suicidio", result says "suicide"/"suicidal"
    const stems = query.split(/\s+/).filter((w) => w.length >= 5).map((w) => w.slice(0, 5));
    const sameTopic = (s) => stems.length > 0 && s.split(/\s+/).some((w) => w.length >= 5 && stems.includes(w.slice(0, 5)));

    result.mentionsHelpline = helplineSignals(norm);
    const emojiCount = count(L.EMOJI, norm);
    const customHit = customBlock.length && customBlock.some((w) => listRe(w).test(norm));
    if (!customHit && !emojiCount && !PREFILTER.test(norm)) { // fast path for clean text
      result.helpline = result.mentionsHelpline && norm.length <= HELPLINE_MAX;
      if (result.helpline) result.factors = ['helpline'];
      if (opts.explain) maskAll(norm, L.MASKS, result.ignored); // the tester still shows what was ignored
      return result;
    }

    const masks = L.MASKS.concat(customAllow.map((w) => ({ t: 'allow', r: listRe(w, 'g') })));
    const perSentence = {};
    CATS.forEach((c) => { perSentence[c] = []; });
    const factors = new Set();
    const hits = result.hits;
    const ignored = result.ignored;

    for (const raw of splitSentences(norm)) {
      const s = maskAll(raw, masks, ignored);
      const fp = has(L.CONTEXT.firstPerson, s);
      const now = has(L.CONTEXT.immediacy, s) && !has(L.CONTEXT.recovery, s);
      const humor = has(L.CONTEXT.humor, raw);
      const local = {};
      const found = [];
      L.TRIGGERS.forEach((tr, id) => {
        tr.r.lastIndex = 0;
        const m = s.match(tr.r);
        if (!m) return;
        // The person's own search echoed back (e.g. they searched "quero morrer"): ignore it,
        // but never ignore methods, so "quero morrer: 7 formas sem dor" is still hidden
        if (query && ECHO.has(tr.t) && (isEcho(m[0].trim()) || (tr.gen && sameTopic(m[0].trim())))) { ignored.push({ t: 'query', text: m[0].trim() }); return; }
        found.push({ tr, id, m, text: m[0].trim() });
      });
      // The same words counted once: a generic hit inside a longer, more specific one is dropped
      // ("suicidal" inside "i feel suicidal")
      found.filter((f) => !(f.tr.gen && found.some((o) => o !== f && o.tr.c === f.tr.c && o.text.length > f.text.length && o.text.includes(f.text)))).forEach(({ tr, id, m, text }) => {
        let w = tr.w * m.length;
        if (tr.gen && fp) { w *= 1.3; factors.add('firstPerson'); }
        if (tr.c === 'suicide' && now && !tr.f) { w *= 1.25; factors.add('immediacy'); }
        if (humor && (tr.hyp || tr.gen)) { w *= 0.45; factors.add('humor'); }
        local[tr.c] = (local[tr.c] || 0) + w;
        hits.push({ id, c: tr.c, t: tr.t, text, w: round(w), m: !!tr.m, f: !!tr.f });
      });
      customBlock.forEach((word) => {
        if (listRe(word).test(s)) {
          local.custom = (local.custom || 0) + 99;
          hits.push({ id: 'custom:' + word, c: 'custom', t: 'custom', text: word, w: 99 });
        }
      });
      for (const c in local) perSentence[c].push(Math.min(5, local[c]));
    }

    // Combine sentences: strongest + half of the second + a quarter of the rest
    const scores = result.scores;
    CATS.forEach((c) => {
      const a = perSentence[c].sort((x, y) => y - x);
      scores[c] = (a[0] || 0) + 0.5 * (a[1] || 0) + 0.25 * a.slice(2).reduce((x, y) => x + y, 0);
    });

    // Context bonuses: several weak cues together are a strong signal (avoids false negatives)
    const distinct = (list) => new Set(list.map((h) => h.text)).size;
    const farewell = hits.filter((h) => h.f);
    const method = hits.filter((h) => h.m);
    const core = hits.some((h) => h.c === 'suicide' && ['ideation', 'burden', 'selfharm', 'euphemism'].includes(h.t));
    const distress = scores.hopeless > 0 || scores.selfworth > 0;
    if (distinct(farewell) >= 3) { scores.suicide += 1.5; factors.add('cluster'); }
    else if (farewell.length && (core || distress || method.length)) { scores.suicide += 1.2; factors.add('cluster'); }
    if (method.length && (core || distress)) { scores.suicide += 1.0; factors.add('cluster'); }
    if (core && distress && !farewell.length && !method.length) { scores.suicide += 0.8; factors.add('cluster'); }
    if (distinct(hits.filter((h) => h.c === 'hopeless')) >= 2) { scores.hopeless += 0.5; factors.add('cluster'); }
    if (distinct(hits.filter((h) => h.c === 'selfworth')) >= 2) { scores.selfworth += 0.5; factors.add('cluster'); }
    if (scores.hopeless > 0 && scores.selfworth > 0) { scores.hopeless += 0.4; scores.selfworth += 0.4; factors.add('cluster'); }
    if (emojiCount && DISTRESS.some((c) => scores[c] > 0)) {
      scores.suicide += Math.min(1, 0.4 * emojiCount);
      hits.push({ id: 'emoji', c: 'suicide', t: 'emoji', text: (norm.match(L.EMOJI) || []).join(' '), w: round(Math.min(1, 0.4 * emojiCount)) });
    }

    // Context reducers (avoid false positives). Method details keep most of their weight.
    const scale = (cats, f) => cats.forEach((c) => { scores[c] *= f; });
    const protS = count(L.CONTEXT.protectiveStrong, norm);
    const protM = count(L.CONTEXT.protectiveMild, norm);
    if (protS >= 2 || (protS >= 1 && protM >= 1)) { scale(DISTRESS, method.length ? 0.7 : 0.35); factors.add('protective'); }
    else if (protS === 1 || protM >= 2) { scale(DISTRESS, method.length ? 0.85 : 0.6); factors.add('protective'); }
    if (norm.length <= 120 && !method.length && has(L.CONTEXT.helpSeeking, norm)) { scale(DISTRESS, 0.4); factors.add('protective'); }
    if (has(L.CONTEXT.recovery, norm) && !has(L.CONTEXT.relapse, norm)) { scale(DISTRESS, method.length ? 0.85 : 0.45); factors.add('recovery'); }
    // Fiction and "informative" framing soften feelings, but not instructions: method details stay heavy
    if (has(L.CONTEXT.fiction, norm)) { scale(['hopeless', 'selfworth', 'hostile', 'news'], 0.75); scale(['suicide'], method.length ? 0.95 : 0.75); factors.add('fiction'); }
    if (has(L.CONTEXT.education, norm)) { scale(['hopeless', 'selfworth', 'news'], 0.8); scale(['suicide'], method.length ? 0.95 : 0.8); factors.add('education'); }
    if (farewell.length && !core && !method.length && !distress && has(L.CONTEXT.leaving, norm)) { scores.suicide *= 0.3; factors.add('leaving'); }
    // A helpline is never hidden (unless the same short text also gives methods, which a real helpline doesn't)
    if (result.mentionsHelpline && norm.length <= HELPLINE_MAX && !method.length) {
      CATS.forEach((c) => { scores[c] = 0; });
      result.helpline = true;
      factors.clear();
      factors.add('helpline');
    }

    // Decide
    const pageBoost = opts.pageBoost || 1;
    let best = null;
    CATS.forEach((c) => {
      if (c !== 'custom' && !enabled[c]) return;
      const thr = THRESHOLDS[level] * CAT_FACTOR[c] * pageBoost;
      const ratio = scores[c] / thr;
      if (scores[c] >= thr && (!best || ratio > best.ratio)) best = { c, thr, ratio };
    });
    CATS.forEach((c) => { scores[c] = round(scores[c]); });
    result.factors = [...factors];
    if (best) {
      result.flag = true;
      result.category = best.c;
      result.score = scores[best.c];
      result.threshold = round(best.thr);
      result.severity = best.ratio >= 2 ? 'high' : 'mid';
    } else {
      const top = CATS.filter((c) => c === 'custom' || enabled[c]).sort((a, b) => scores[b] - scores[a])[0];
      result.category = scores[top] > 0 ? top : null;
      result.score = top ? scores[top] : 0;
      result.threshold = top ? round(THRESHOLDS[level] * CAT_FACTOR[top] * pageBoost) : THRESHOLDS[level];
    }
    return result;
  }

  // Find the original wording (with accents and capitals) of a normalised snippet, for display.
  function locate(original, snippet) {
    let flat = '';
    const map = [];
    for (let i = 0; i < original.length; i++) {
      const c = original[i].normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[’‘`´]/g, "'").replace(/-/g, ' ');
      for (const ch of c) { flat += ch; map.push(i); }
    }
    const at = flat.indexOf(snippet);
    return at < 0 ? snippet : original.slice(map[at], map[at + snippet.length - 1] + 1);
  }

  // Unique explanation tags, strongest first, for the "Why?" view.
  function explain(res) {
    const tags = new Map();
    res.hits.slice().sort((a, b) => b.w - a.w).forEach((h) => {
      if (!tags.has(h.t)) tags.set(h.t, h.t === 'emoji' || h.t === 'custom' ? h.text : locate(res.original || '', h.text));
    });
    const ignored = new Map();
    res.ignored.forEach((i) => { const text = locate(res.original || '', i.text); if (!ignored.has(text)) ignored.set(text, i.t); });
    return { tags: [...tags.entries()].map(([t, text]) => ({ t, text })), factors: res.factors, ignored: [...ignored.entries()].map(([text, t]) => ({ t, text })) };
  }

  MS.classifier = { classify, explain, normalize, THRESHOLDS, mentionsHelpline: (text) => helplineSignals(normalize(String(text || '').slice(0, 4000))) };
  MS.classify = classify;
})();
