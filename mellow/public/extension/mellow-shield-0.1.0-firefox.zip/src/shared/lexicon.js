/*
 * Mellow Shield — lexicon (PT-PT, PT-BR, EN).
 * Text is matched AFTER normalisation: lower case, no accents, hyphens between letters
 * become spaces ("matar-me" -> "matar me"), leetspeak and censoring undone.
 *
 * TRIGGERS  w = weight, c = category, t = explanation tag
 *           gen = generic phrase (full weight only in the first person)
 *           hyp = often used as a joke / hyperbole (weight drops with laughter)
 *           m   = method or plan (raises suicide risk when it appears with other cues)
 *           f   = farewell cue (weak alone, strong in clusters)
 * MASKS     phrases that look negative but are not (idioms, objects that "die",
 *           negations). They are blanked out before triggers are matched.
 * CONTEXT   block-level signals that lower or raise the score.
 */
(function () {
  const MS = (globalThis.MellowShield = globalThis.MellowShield || {});

  const TRIGGERS = [
    // ---------------- Suicidal ideation (PT) ----------------
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(ja )?nao quero (mais )?(viver|estar ca|estar aqui|existir|acordar)\b/g },
    { c: 'suicide', t: 'ideation', w: 3, hyp: 1, r: /\b(quero|queria|apetece me|so quero|so queria|tenho vontade de) (morrer|desaparecer para sempre|deixar de existir|nao acordar)\b/g },
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(quero|queria|vou|ia|penso em|estou a pensar em|ando a pensar em|tenho vontade de|apetece me|devia) (me matar|matar me|suicidar me|me suicidar|acabar com a minha vida|tirar a minha (propria )?vida|por fim a minha vida)\b/g },
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(vou me|me vou|quero me|me quero|ia me|me ia) (matar|suicidar)\b/g },
    { c: 'suicide', t: 'ideation', w: 1.8, gen: 1, r: /\b(acabar com tudo|por fim a tudo|acabar com isto de vez)\b/g },
    { c: 'suicide', t: 'ideation', w: 1.8, hyp: 1, r: /\b(quero|queria|so quero|so queria) (sumir|desaparecer)\b/g },
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(morrer|morte|suicidio|suicide|death|dying|dead) (e|is|seems|feels like|parece) (a |the )?(unica|melhor|only|best) (saida|solucao|way out|option|answer)\b/g },
    { c: 'suicide', t: 'ideation', w: 2.5, r: /\b(estou|ando|sinto me) (farto|farta|cansado|cansada|exausto|exausta) de viver\b/g },
    { c: 'suicide', t: 'ideation', w: 2.5, r: /\b(era|seria) melhor (eu )?(morrer|estar morto|estar morta|nao existir|nao ter nascido)\b/g },
    { c: 'suicide', t: 'ideation', w: 2.4, r: /\b(ja )?nao aguento (mais )?(viver|esta vida|estar vivo|estar viva)\b/g },
    { c: 'suicide', t: 'burden', w: 2.4, r: /\b(sou|sinto me) (um|uma) (peso|fardo)\b/g },
    { c: 'suicide', t: 'burden', w: 2.4, r: /\b(ficavam|ficariam|estariam|viviam|viveriam) (todos )?melhor sem mim\b/g },
    { c: 'suicide', t: 'burden', w: 2.4, r: /\bninguem (ia|iria|vai|ira) (notar|reparar|sentir a (minha )?falta)\b/g },
    { c: 'suicide', t: 'ideation', w: 1.6, gen: 1, r: /\b(pensamentos suicidas|ideacao suicida|vontade de morrer)\b/g },
    { c: 'suicide', t: 'ideation', w: 1.2, gen: 1, r: /\b(suicidio|suicidar|suicida|se matou|se suicidou|tirou a propria vida|tirar a propria vida)\b/g },

    // ---------------- Suicidal ideation (EN) ----------------
    { c: 'suicide', t: 'ideation', w: 3, hyp: 1, r: /\bi (just |really |honestly |kinda |literally )?(want|wanna|wish i could|need) (to )?(die|disappear forever|stop existing|not wake up|not exist)\b/g },
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(kill|killing|end|ending|take|taking) (myself|my life|my own life)\b/g },
    { c: 'suicide', t: 'ideation', w: 1.8, hyp: 1, r: /\bi (just |really )?(want|wanna) (to )?disappear\b/g },
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(don'?t|do not|no longer) (want|wanna) (to )?(live|be alive|exist|be here)( anymore)?\b/g },
    { c: 'suicide', t: 'ideation', w: 2.6, gen: 1, r: /\b(end it all|ending it all|end it tonight|end things tonight)\b/g },
    { c: 'suicide', t: 'ideation', w: 2.6, r: /\bwish i (was|were) (dead|never born|gone)\b/g },
    { c: 'suicide', t: 'ideation', w: 2.5, gen: 1, r: /\b(tired|sick) of (living|being alive)\b/g },
    { c: 'suicide', t: 'ideation', w: 2.5, gen: 1, r: /\bbetter off dead\b/g },
    { c: 'suicide', t: 'burden', w: 2.4, r: /\b(i'?m|i am|i feel like) (just )?(a|such a) burden\b/g },
    { c: 'suicide', t: 'burden', w: 2.4, r: /\b(everyone|everybody|they|people|my family|my friends) (would be|'?d be|are|will be) better off without me\b/g },
    { c: 'suicide', t: 'burden', w: 2.4, r: /\b(no ?one|nobody) (would|will|'?d) (even )?(notice|care|miss me)( if i (was|were) gone| if i disappeared| if i died)?\b/g },
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(i'?m|i am|i feel|i'?ve been|feeling|i get|i keep feeling) (so |really |very |kinda |a bit |extremely )?suicidal\b/g },
    { c: 'suicide', t: 'ideation', w: 1.2, gen: 1, r: /\b(suicidal|thoughts of suicide|suicidal thoughts)\b/g },
    { c: 'suicide', t: 'ideation', w: 3, r: /\b(tenho|ando com|estou com|tive) (pensamentos suicidas|ideias suicidas|ideacao suicida|vontade de morrer)\b/g },
    { c: 'suicide', t: 'ideation', w: 1.2, gen: 1, r: /\b(suicide|killed (him|her|them)self|killed (him|her|them)selves|took (his|her|their) own life)\b/g },

    // ---------------- Euphemisms and coded language ----------------
    { c: 'suicide', t: 'euphemism', w: 2.6, hyp: 1, r: /\b(kms|unalive (myself|me)|self ?unalive|sewerslide|commit sudoku|ropemaxx?ing)\b/g },
    { c: 'suicide', t: 'euphemism', w: 1.4, r: /\b(unalive|ctb|catch the bus|dormir para sempre|nao acordar mais|ir dormir e nao acordar|go to sleep forever|never wake up again)\b/g },

    // ---------------- Self-harm ----------------
    { c: 'suicide', t: 'selfharm', w: 2.6, r: /\b(cortei me|corto me|cortar me|me cortei|me cortar|magoei me de proposito|magoar me de proposito|automutila\w*|autolesao|auto lesao|queimei me de proposito)\b/g },
    { c: 'suicide', t: 'selfharm', w: 2.6, r: /\b(self ?harm(ing)?|cut(ting)? myself|i cut again|relapsed? (on|with) (sh|self ?harm)|burn(ing|ed|t)? myself on purpose|hurt(ing)? myself on purpose)\b/g },

    // ---------------- Method or plan ----------------
    { c: 'suicide', t: 'plan', w: 1.6, m: 1, r: /\b(juntar|guardar|acumular|tomar|engolir|tenho) (os |todos os |uma caixa de |muitos |varios )?(comprimidos|medicamentos|pilulas)( guardados| todos)?\b/g },
    { c: 'suicide', t: 'plan', w: 1.6, m: 1, r: /\b(saltar|atirar me|me atirar) (da|de uma|de um|do|pela) (ponte|janela|predio|varanda|telhado|comboio|metro)\b/g },
    { c: 'suicide', t: 'plan', w: 1.6, m: 1, r: /\b(carta de despedida|bilhete de despedida|enforcar me|me enforcar|cortar os pulsos)\b/g },
    { c: 'suicide', t: 'plan', w: 1.6, m: 1, r: /\b(stockpil\w* (pills|meds|tablets)|(saving|save|swallow\w*|take|taking|took) all (of )?(my |the |these )?(pills|meds|tablets))\b/g },
    { c: 'suicide', t: 'plan', w: 1.6, m: 1, r: /\b(jump(ing)? (off|from) (a|the|this) (bridge|building|roof|cliff)|suicide note|goodbye letter|hang(ing)? myself|noose|slit(ting)? my wrists|overdos(e|ing))\b/g },
    { c: 'suicide', t: 'plan', w: 0.7, m: 1, r: /\b(corda|lamina|laminas|navalha|rope|razor|razors|blade|blades)\b/g },
    // Method-seeking wording, common in search results and "People also ask"
    { c: 'suicide', t: 'plan', w: 2.4, m: 1, r: /\b((metodos?|formas?|maneiras?|tecnicas?|meios|methods?|ways?|means) (de|para|of|for|to commit|of committing|of commiting|for committing|used in|used for) (suicidio|suicide|se suicidar|suicidar se|cometer suicidio)|(suicide|suicidal|suicidio) (methods?|means|techniques?)|metodos? (de )?suicid(a|as|io)|method specific (risk|suicide)|(metodos|formas|maneiras|methods|ways) mais (rapid[ao]s|faceis|indolores|eficazes))\b/g },
    { c: 'suicide', t: 'plan', w: 2.6, m: 1, r: /\b(como|how to|how do i|how can i|ways to|best way to|easiest way to|quickest way to|painless way to|formas? de|maneiras? de|metodos? (de|para)|(melhor|pior) (forma|maneira) de|(forma|maneira|jeito|metodo) mais (rapid[ao]|facil|indolor|eficaz|segur[ao]) de) (me matar|matar me|suicidar me|me suicidar|cometer suicidio|tirar a minha (propria )?vida|acabar com a minha vida|kill (myself|yourself)|commit suicide|end (my|your) (own )?life|unalive (myself|yourself))\b/g },
    { c: 'suicide', t: 'plan', w: 1.4, m: 1, r: /\b((formas?|maneiras?|metodos?)( \w+){0,4} (de|para) (morrer|acabar com tudo|acabar com a vida|tirar a vida)|(ways|methods)( \w+){0,3} to (die|end it all|end your life)|how to die)\b/g },
    { c: 'suicide', t: 'plan', w: 1.6, m: 1, r: /\b(sem dor|indolor\w*|painless\w*|pain free|quickest|easiest|fastest|mais rapid[ao]|mais facil)\b(?=.{0,40}\b(morrer|morte|suicid\w*|die|death|kill\w*|matar|acabar com (tudo|a vida)|tirar a vida|end it)\b)|\b(morrer|morte|suicid\w*|die|death|kill\w*|matar)\b.{0,50}\b(sem dor|indolor\w*|painless\w*|pain free|quickly|rapidamente|mais rapid[ao]|mais facil|quickest|easiest)\b/g },
    { c: 'suicide', t: 'plan', w: 1.6, m: 1, r: /\b(escolher|decidir|choose|pick|decide on) (a |o |the )?(forma|maneira|metodo|way|method)\b/g },
    { c: 'suicide', t: 'plan', w: 2.6, m: 1, r: /\b(doses? (letal|letais|fatal|fatais|mortal|mortais)|lethal dose|fatal dose|lethal amount|quantos comprimidos (para|e preciso para|sao precisos para) (morrer|matar)|how many (pills|tablets) (to|does it take to) (die|kill|overdose))\b/g },

    // ---------------- Farewell cues (weak alone, strong together) ----------------
    { c: 'suicide', t: 'farewell', w: 1.4, f: 1, r: /\b(ja tratei de tudo|ja deixei tudo tratado|podes ficar com (as )?minhas coisas|esta e a minha ultima (mensagem|publicacao)|nao vou estar ca (amanha|mais)|cuidem (bem )?(do meu|da minha) (gato|cao|filho|filha|familia))\b/g },
    { c: 'suicide', t: 'farewell', w: 1.0, f: 1, r: /\b(obrigad[oa] por tudo|desculpem( me)? por tudo|isto e um adeus|adeus a todos|foi bom conhecer vos|a minha ultima noite)\b/g },
    { c: 'suicide', t: 'farewell', w: 1.4, f: 1, r: /\b(i'?ve (made my peace|put my affairs in order)|take care of my (cat|dog|kids|family|pets?)|this is my (last|final) (post|message)|i won'?t be (around|here) (much longer|tomorrow|anymore)|you won'?t have to deal with me)\b/g },
    { c: 'suicide', t: 'farewell', w: 1.0, f: 1, r: /\b(thank you for everything|sorry for everything|this is goodbye|goodbye everyone|it was nice knowing you)\b/g },

    // ---------------- Hopelessness ----------------
    { c: 'hopeless', t: 'hopeless', w: 2.0, r: /\b(nada (vai|ira) mudar|nunca (vai|ira) melhorar|isto nunca vai passar|nao ha saida|nao ha esperanca|nao vale a pena (viver|continuar|tentar mais)|para que (continuar|viver|tentar)|a vida nao tem (sentido|significado))\b/g },
    { c: 'hopeless', t: 'hopeless', w: 1.5, gen: 1, r: /\b(ja nao aguento|nao aguento mais|nao consigo mais|estou no limite|nao vejo futuro|sem futuro)\b/g },
    { c: 'hopeless', t: 'hopeless', w: 1.8, r: /\b(a unica saida|e a unica saida|the only way out|only way out)\b/g },
    { c: 'hopeless', t: 'hopeless', w: 1.2, gen: 1, r: /\b(sem esperanca|desesperad[oa]|vazi[oa] por dentro|nao sinto nada|cansad[oa] de tudo|fart[oa] de tudo|ninguem se importa|tudo e inutil|tudo e em vao)\b/g },
    { c: 'hopeless', t: 'hopeless', w: 2.0, r: /\b(nothing (will|is going to|is ever going to) (ever )?(change|get better)|(it|things|life) (will|is going to) never get better|(there'?s )?no way out|there'?s no hope|no point (in )?(living|trying|going on)|life (is meaningless|has no (meaning|point))|what'?s the point of living)\b/g },
    { c: 'hopeless', t: 'hopeless', w: 1.5, r: /\b(i can'?t (do this|take (it|this)|go on|keep going) anymore|i give up on (everything|life)|i'?m at my limit|no future for me)\b/g },
    { c: 'hopeless', t: 'hopeless', w: 1.2, gen: 1, r: /\b(hopeless|i feel (so )?empty|empty inside|i feel nothing|tired of everything|nobody cares|no one cares|everything is pointless)\b/g },
    { c: 'hopeless', t: 'hopeless', w: 0.8, gen: 1, hyp: 1, r: /\b(what'?s the point|para que serve isto tudo|que se lixe tudo)\b/g },

    // ---------------- Self-criticism ----------------
    { c: 'selfworth', t: 'selfworth', w: 1.8, r: /\b(sou um fracasso|sou uma falhada|sou um falhado|nao valho nada|odeio me|me odeio|nao sirvo para nada|sou (um |uma )?inutil|sou um lixo|sou nojent[oa]|sou horrivel|estrago tudo|nunca vou ser suficiente|toda a gente me odeia|ninguem gosta de mim)\b/g },
    { c: 'selfworth', t: 'selfworth', w: 1.8, r: /\b(i'?m (such )?a (failure|disappointment|waste of space)|i'?m (so )?(worthless|useless|pathetic|disgusting)|i hate myself|i ruin everything|i'?ll never be good enough|everyone hates me|(nobody|no one) (likes|loves) me)\b/g },
    { c: 'selfworth', t: 'selfworth', w: 1.3, hyp: 1, r: /\b(odeio a minha vida|i hate my life|i'?m not good enough|sou fei[oa]|i'?m ugly)\b/g },

    // ---------------- Attacks aimed at the reader ----------------
    { c: 'hostile', t: 'hostile', w: 3.0, r: /\b(mata te|vai te matar|devias (morrer|matar te|desaparecer)|se mata|vai se matar|espero que morras|kys|kill yourself|go die|you should (die|kill yourself)|neck yourself|end yourself|hope you die)\b/g },
    { c: 'hostile', t: 'hostile', w: 2.0, r: /\b(ninguem gosta de ti|toda a gente te odeia|es (um |uma )?(inutil|fracasso|lixo|nojent[oa])|(nobody|no one) (likes|loves|wants) you|everyone hates you|you'?re (worthless|useless|pathetic|a failure)|you are (worthless|useless|pathetic|a failure)|do (the world|everyone|us all) a favou?r|faz um favor ao mundo)\b/g },

    // ---------------- Distressing news (off by default) ----------------
    { c: 'news', t: 'news', w: 1.0, gen: 1, r: /\b(morreu|morreram|mort[oa]s|vitimas|tragedia|massacre|tiroteio|atentado|homicidio|assassinad[oa]|died|killed|victims|tragedy|shooting|terror attack|murder(ed)?|fatal crash)\b/g },
  ];

  const MASKS = [
    // Idioms built on death / killing words
    { t: 'idiom', r: /\b(morr\w*|mort[oa]s?) (a|de) (rir|riso|vergonha|tedio|fome|sede|calor|frio|saudades?|amores|inveja|sono|cansaco|medo|curiosidade|ciumes|pena)\b/g },
    { t: 'idiom', r: /\b(mata\w*|matar) (me |te )?(de|a) (rir|vergonha|susto|saudades?|trabalhar|estudar)\b/g },
    { t: 'idiom', r: /\bmatar (a fome|a sede|saudades|as saudades|o tempo|o bicho|a curiosidade)\b/g },
    { t: 'idiom', r: /\b(sumir|desaparecer|disappear) (de|from|out of) (vergonha|cansaco|embarrassment|shame)\b/g },
    { t: 'idiom', r: /\b(vamos acabar com tudo|acabar com tudo (e|para) (recomecar|comecar))\b/g },
    { t: 'idiom', r: /\b(calor|frio|exame|exames|teste|testes|trabalho|transito|dor de cabeca|dores|semana|segunda feira|reuniao|reunioes|treino|ginasio|faculdade|escola|chefe|isto|esta musica|este jogo|este video|os meus pes|as costas)( \w+){0,3} (a matar me|matar me|me mata|me matando|me esta a matar|me vai matar|mata me)\b/g },
    { t: 'idiom', r: /\b(dying|died|dead|die|i'?m dead|i'?m dying) (of |from |with )?(laughter|laughing|embarrassment|boredom|cringe|cuteness)\b/g },
    { t: 'idiom', r: /\b(i'?m|im) (dead|dying|deceased|crying)( (lol|lmao|lmfao|haha\w*)|\s*💀|\s*😂|\s*🤣)/gu },
    { t: 'idiom', r: /\b(killing it|killed it|to die for|dead tired|bored to death|scared to death|worried sick|die hard|dying to (see|try|know|meet|go|hear|watch|read|get)|would kill for|kill two birds|kill(ing)? time|killer (app|feature|deal|look|move|outfit|track)|cut(ting)? myself (some )?slack|take my life back|my life back|could die of embarrassment)\b/g },
    { t: 'idiom', r: /\b(this|that|work|school|traffic|the heat|this heat|homework|this exam|exams|mondays?|my feet|my back|this song|this game|this show|the commute|deadlines?|this week|my boss)( \w+){0,2} (is|are|'?s) killing me\b/g },
    { t: 'idiom', r: /\b(suicide squad|suicide doors?|suicide runs?|suicide sprints?|suicide burn|suicide king|kill switch|kill (the )?process|process killed|killer whale)\b/g },
    // Things (not people) that "die"
    { t: 'object', r: /\b(bateria|telemovel|telefone|celular|portatil|computador|pc|carro|servidor|pilha|planta|router|wifi|internet|jogo|serie|app|projeto|meme|ecra|tela|disco|consola|comando)( \w+){0,3} (morreu|esta mort[oa]|morta|morto|ja era)\b/g },
    { t: 'object', r: /\b(battery|phone|laptop|computer|pc|car|server|plant|router|wifi|internet|game|show|series|meme|thread|trend|joke|project|vibe|screen|drive|console|controller|chat|conversation|party)( \w+){0,3} (died|is dead|dead|dying)\b/g },
    // Negations. "ja nao" (no longer) is NOT a negation: "ja nao quero viver" stays a trigger.
    { t: 'negation', r: /(?<!\bja )\bnao (quero|vou|tenciono|penso em|estou a pensar em) (morrer|me matar|matar me|suicidar me|me suicidar|magoar me|me magoar|acabar com a minha vida)\b/g },
    { t: 'negation', r: /\b(nunca|jamais) (me )?(faria isso|faria|mataria|magoaria|suicidaria)( me)?\b/g },
    { t: 'negation', r: /\bnao (sou|estou|me sinto) suicida\b|\bnao tenho (pensamentos suicidas|ideacao suicida)\b/g },
    { t: 'negation', r: /\bi (do not|don'?t|would never|will never|won'?t|never|am not going to|'?m not going to) (want to |wanna |ever )?(die|kill myself|hurt myself|harm myself|end my life)\b/g },
    { t: 'negation', r: /\b(i'?m|i am) not suicidal\b|\bnot suicidal\b|\bnever (been|felt) suicidal\b|\bno (suicidal thoughts|thoughts of suicide)\b/g },
  ];

  const CONTEXT = {
    protectiveStrong: /\b(linha (de apoio|de prevencao|de crise)|sns 24|sos voz amiga|voz amiga|prevencao (do|ao) suicidio|liga (para )?(o )?112|ligue (para )?(o )?(112|188)|cvv|mieli|nao estas sozinh[oa]|voce nao esta sozinh[oa]|helpline|hotline|crisis (line|text line|center|centre)|lifeline|samaritans|suicide prevention|988|you'?re not alone|you are not alone|text home to|befrienders)\b/g,
    protectiveMild: /\b(pede ajuda|procura ajuda|pedir ajuda|falar com alguem|apoio psicologico|psicolog[oa]|psiquiatra|terapia|terapeuta|sinais de alerta|como ajudar|reach out|talk to someone|seek help|get help|ask for help|warning signs|how to help|therapist|therapy|counsell?or|support group)\b/g,
    recovery: /\b(ja passei por isso|sai da depressao|superei|estou melhor|estou a melhorar|hoje estou bem|recuperei|em recuperacao|i got better|it gets better|i'?m doing better|i'?m better now|recovered|in recovery|(years?|months?|days?) clean|i survived|sobrevivi)\b/g,
    relapse: /\b(relaps\w*|recai\w*|voltei a|again|outra vez|de novo|novamente)\b/g,
    // Someone looking for help (search suggestions, questions): "quero morrer ajuda", "i want to die what to do"
    helpSeeking: /\b(ajuda|o que fazer|que fazer|o que devo fazer|o que faco|onde pedir|com quem falar|apoio|help|what to do|what should i do|what do i do|who to talk to|how to cope|como lidar)\b/g,
    fiction: /\b(filme|serie|livro|romance|personagem|episodio|temporada|trailer|critica|spoiler|movie|film|book|novel|character|episode|season|anime|manga|lyrics|letra|cancao|song|album|videojogo|video game|fanfic)\b/g,
    education: /\b(estudo|estudos|investigadores|investigacao|segundo a oms|oms|sintomas|tratamento|estatisticas|sinais (de|que)|fatores de risco|o que e|study|studies|researchers|research|according to|symptoms|treatment|statistics|prevalence|clinical|signs (of|that)|risk factors|what (is|are))\b/g,
    humor: /(\b(lol|lmao|lmfao|rofl|haha\w*|hehe\w*|kk+|rsrs\w*|xd)\b|😂|🤣|💀|😆)/gu,
    leaving: /(\b(ultimo dia|novo emprego|nova etapa|nova aventura|proximo capitulo|reforma|colegas|equipa|last day|new job|new role|next chapter|new adventure|retir(ing|ement)|moving on to|my team|colleagues|graduat\w*)\b|🎉|🥳)/gu,
    firstPerson: /\b(eu|me|mim|meu|minha|meus|minhas|comigo|estou|sou|quero|queria|vou|tenho|sinto|odeio|aguento|consigo|penso|preciso|estava|fui|fiz|ando|i|i'?m|im|my|myself|mine|i'?ve|i'?ll|i'?d)\b/g,
    immediacy: /\b(hoje|esta noite|logo a noite|amanha|agora|ja decidi|daqui a pouco|em breve|tonight|today|tomorrow|right now|soon|this weekend|i'?ve decided)\b/g,
  };

  // Helplines: a named line or a "help is available" header, together with a number. Never hidden.
  const HELPLINE = {
    name: /\b(sos voz amiga|voz amiga|sns 24|linha sns 24|telefone da amizade|conversa amiga|linha vida|linha de apoio|linha de prevencao|linha de crise|linha telefonica|mieli|kriisipuhelin|sekasin|cvv|centro de valorizacao da vida|samaritans|suicide (and|&) crisis lifeline|lifeline|crisis text line|befrienders|telefono amico|nightline|hotline|helpline|crisis line)\b/,
    head: /\b(ajuda disponivel|ha ajuda disponivel|fala com alguem hoje|fale com alguem hoje|help is available|speak with someone today|talk to someone today|you are not alone|nao estas sozinh[oa]|voce nao esta sozinh[oa]|precisas de ajuda agora|need help now)\b/,
    phone: /(\+?\d[\d ().-]{6,}\d|\b(112|988|116 ?123|116 ?111|741741|188)\b)/,
  };
  // Trigger types that, on a search page, may just be the user's own query echoed back
  const ECHO_TAGS = ['ideation', 'burden', 'hopeless', 'selfworth', 'selfharm', 'euphemism', 'farewell'];

  const EMOJI = /(🪦|⚰️|⚰|🔪|🩸|💊|🪢|🥀)/gu;

  // Words that leetspeak, spacing or censoring is undone for ("s*icide", "s u i c i d e", "k1ll")
  const SENSITIVE_WORDS = ['suicide', 'suicidal', 'suicidio', 'suicidar', 'suicida', 'kill', 'killing', 'myself', 'die', 'dying', 'dead', 'death', 'morrer', 'matar', 'morte', 'cutting', 'selfharm', 'overdose', 'unalive', 'kms', 'kys'];
  const COMPOUNDS = { killmyself: 'kill myself', endmylife: 'end my life', selfharm: 'self harm', kmsnow: 'kms now' };

  MS.lexicon = { TRIGGERS, MASKS, CONTEXT, HELPLINE, ECHO_TAGS, EMOJI, SENSITIVE_WORDS, COMPOUNDS };
})();
