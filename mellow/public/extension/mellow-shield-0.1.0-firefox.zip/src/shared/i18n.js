/* Mellow Shield — interface text (English only).
 * Written in Mellow's own voice: short, first person, no jargon. */
(function () {
  const MS = (globalThis.MellowShield = globalThis.MellowShield || {});

  const STR = {
    en: {
      status_on: 'Looking out for you', status_off: 'Off', status_paused: 'Paused on this site',
      theme_to_night: 'Switch to night', theme_to_day: 'Switch to day', theme_day: 'Day mode', theme_night: 'Night mode',
      site_on: 'On for {site}', site_paused: 'Paused on {site}', no_site: 'I can’t work on this page.',
      pause_site: 'Pause here', resume_site: 'Resume',
      checkin_title: 'How are you feeling today?',
      mood_heavy: 'Heavy', mood_low: 'Low', mood_okay: 'Okay', mood_good: 'Good', mood_bright: 'Bright',
      reply_heavy: 'Thanks for telling me. I’ll hide a bit more today, and we can breathe together if you like.',
      reply_low: 'Noted. I’ll hide a bit more today, just in case.',
      reply_okay: 'Got it. Everything stays as it is.',
      reply_good: 'Glad to hear it. Everything stays as it is.',
      reply_bright: 'Lovely to hear.',
      today_none: 'Nothing hidden yet today.',
      today_one: 'Today I hid {n} thing that could weigh on you.',
      today_many: 'Today I hid {n} things that could weigh on you.',
      week: '{n} in the last 7 days',
      count_one: 'thing I kept out of your way today', count_many: 'things I kept out of your way today', count_none: 'nothing to hide today, so far',
      weekdays: 'S M T W T F S',
      level_title: 'How much to hide',
      level_gentle: 'Less', level_balanced: 'Normal', level_protective: 'More',
      level_desc_gentle: 'I only hide what is really clear.',
      level_desc_balanced: 'What I’d suggest for most days.',
      level_desc_protective: 'I also hide subtler things. Good for hard days.',
      raised_note: 'Because of your check-in, I’m on “{level}” today.',
      breathe_btn: 'Breathe for a bit', settings_btn: 'Settings',
      breathe_in: 'Breathe in', breathe_hold: 'Hold', breathe_out: 'Breathe out',
      breathe_ready: 'Three slow breaths. It takes less than a minute.',
      breathe_count: 'Breath {n} of 3', breathe_done: 'Well done. Come back whenever you need.',
      begin: 'Start', close: 'Close',
      support_title: 'Need to talk to someone?',
      support_112: 'In danger: 112 (Finland and the rest of the EU).',
      support_fi: 'Finland · MIELI crisis line, 24 h: 09 2525 0111',
      privacy: 'Everything stays in this browser. I send nothing.',
      perm_needed: 'The browser hasn’t let me see pages yet.',
      perm_btn: 'Give access',
      banner_title: 'Hidden, just in case', banner_title_warn: 'This might weigh on you',
      about_suicide: 'It talks about suicide or self-harm.', about_hopeless: 'It talks about hopelessness.',
      about_selfworth: 'Someone is being very hard on themselves.', about_hostile: 'It has an attack aimed at someone.',
      about_news: 'It’s heavy news.', about_custom: 'It has a word you asked me to hide.',
      banner_help: 'If you need to talk to someone right now, call 112.',
      show: 'Show', why: 'Why?', hide_again: 'Hide again', shown: 'You’re looking at something I had hidden.',
      cat_suicide: 'Suicide and self-harm', cat_hopeless: 'Hopelessness', cat_selfworth: 'Self-criticism',
      cat_hostile: 'Attacks', cat_news: 'Heavy news', cat_custom: 'Your words',
      catdesc_suicide: 'Thoughts of dying, goodbyes, methods and self-harm. I’d keep this on.',
      catdesc_hopeless: '“Nothing will change”, “no way out”, feeling empty.',
      catdesc_selfworth: '“I’m a failure”, “I hate myself”, “nobody likes me”.',
      catdesc_hostile: 'Things said to someone, like “kys” or “nobody likes you”.',
      catdesc_news: 'Deaths, tragedies and violence in the news. Off to start with.',
      tag_ideation: 'Thoughts of dying', tag_burden: 'Feeling like a burden', tag_selfharm: 'Self-harm',
      tag_plan: 'Plan or method', tag_farewell: 'Goodbye', tag_euphemism: 'Disguised wording',
      tag_emoji: 'Related emoji', tag_hopeless: 'Hopelessness', tag_selfworth: 'Self-criticism',
      tag_hostile: 'Targeted attack', tag_news: 'Heavy news', tag_custom: 'Your word',
      ctx_firstPerson: 'It’s written in the first person', ctx_immediacy: 'It talks about today or now',
      ctx_cluster: 'Several cues together in the same text', ctx_protective: 'It’s about getting help, so it weighs less',
      ctx_recovery: 'It’s a recovery story, so it weighs less', ctx_fiction: 'It looks like fiction or culture, so it weighs less',
      ctx_education: 'It looks informative, so it weighs less', ctx_leaving: 'It’s a happy goodbye, so it weighs less',
      ctx_humor: 'It sounds like a joke, so it weighs less',
      ctx_helpline: 'It’s a helpline: these are never hidden',
      ign_idiom: 'Idiom', ign_object: 'Not about a person', ign_negation: 'Negation',
      ign_allow: 'A word you never hide', ign_query: 'Part of your own search',
      opt_sub: 'Settings',
      sec_protection: 'Protection', sec_categories: 'What to hide', sec_tester: 'Try it',
      sec_lists: 'Words and sites', sec_privacy: 'Privacy and support',
      protection_lead: 'Choose how much I hide, and how.',
      categories_lead: 'Turn on only what makes sense for you. You can change it any time.',
      tester_lead: 'Type a sentence and see what I’d do with it. I read the whole sentence, so “I’m dying laughing” stays visible and “I don’t want to live anymore” doesn’t.',
      lists_lead: 'Words you always or never want hidden, and sites where you’d rather I didn’t step in.',
      privacy_lead: 'I don’t send anything anywhere. Your settings and numbers stay in this browser only.',
      mode_title: 'How to hide',
      mode_blur: 'Blur', mode_hide: 'Remove', mode_warn: 'Warn only',
      modedesc_blur: 'The text is blurred, with a note on top.',
      modedesc_hide: 'The text is gone for good. Only the note stays, and you can see why.',
      modedesc_warn: 'The text stays visible, with a note before it.',
      preview_name: 'Someone', preview_banner: 'Hidden, just in case', preview_warn: 'This might weigh on you',
      adapt_title: 'Follow my mood',
      adapt_desc: 'On days you tell me you feel low, I hide a bit more.',
      tester_placeholder: 'Type a sentence here…', tester_try: 'Or try one of these:',
      result_flag: 'This would be hidden.', result_ok: 'This would stay visible.',
      near_far_above: 'Well above the line', near_above: 'Above the line', near_close: 'Close to the line, but below', near_below: 'Far from the line',
      result_numbers: 'Show numbers', result_numbers_line: 'Score {score}, line {thr}.',
      result_found: 'What I found', result_context: 'What I took into account', result_ignored: 'What I ignored on purpose',
      result_empty: 'I didn’t find anything heavy.',
      words_block: 'Always hide', words_allow: 'Never hide', words_hint: 'One per line.',
      save: 'Save', sites_title: 'Paused sites', sites_empty: 'You haven’t paused any sites yet.',
      sites_placeholder: 'example.com', add: 'Add', remove: 'Remove',
      reset_stats: 'Clear the numbers', stats_cleared: 'Numbers cleared', toast_saved: 'Saved',
      back: 'Back', test_title: 'Try a sentence', tab_filter: 'Filter', tab_sites: 'Sites', tab_more: 'More',
      block_title: 'Blocked sites', block_desc: 'They don’t open at all. A calm Mellow page shows up instead.',
      block_empty: 'You haven’t blocked any sites yet.', block_site: 'Block this site', block_add: 'Block',
      blocked_on: '{site} is blocked', blocked_h: 'This site is blocked',
      blocked_p: 'You asked me not to open {site}. Maybe that’s for the best, at least today.',
      blocked_back: 'Go back', blocked_breathe: 'Breathe with me', blocked_unblock: 'Unblock',
      blocked_wait: 'Wait {n} s…', blocked_sure: 'Unblock anyway', blocked_note: 'Unblocking takes {site} off the list. Think about it for ten seconds.',
      disclaimer: 'Mellow Shield helps, but it won’t catch everything and it isn’t a substitute for a professional.',
    },
  };

  let lang = 'en';
  // English only: kept as a no-op so existing callers keep working
  function setLang() { return lang; }
  function t(key, vars) {
    let s = STR.en[key] || key;
    if (vars) Object.keys(vars).forEach((k) => { s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }
  // Fill every [data-i18n] / [data-i18n-placeholder] element in a page
  function apply(root) {
    (root || document).querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.getAttribute('data-i18n')); });
    (root || document).querySelectorAll('[data-i18n-placeholder]').forEach((el) => { el.setAttribute('placeholder', t(el.getAttribute('data-i18n-placeholder'))); });
    (root || document).querySelectorAll('[data-i18n-aria]').forEach((el) => { const s = t(el.getAttribute('data-i18n-aria')); el.setAttribute('aria-label', s); el.title = s; });
    if (globalThis.document) document.documentElement.lang = 'en';
  }

  setLang('auto');
  MS.i18n = { t, setLang, apply, get lang() { return lang; } };
})();
