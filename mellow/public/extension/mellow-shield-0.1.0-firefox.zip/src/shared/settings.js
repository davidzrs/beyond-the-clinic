/* Mellow Shield — settings, daily mood and local statistics (all stored on the device). */
(function () {
  const MS = (globalThis.MellowShield = globalThis.MellowShield || {});

  const DEFAULTS = {
    enabled: true,
    level: 'balanced',            // gentle | balanced | protective
    mode: 'blur',                 // blur | hide | warn
    adaptToMood: true,            // heavy/low check-in raises protection by one level
    categories: { suicide: true, hopeless: true, selfworth: true, hostile: true, news: false },
    pausedSites: [],
    blockedSites: [],             // never opened: a calm Mellow page shows instead
    customBlock: [],
    customAllow: [],
    lang: 'auto',
    mood: null,                   // { value: 'heavy'|'low'|'okay'|'good'|'bright', date: 'YYYY-MM-DD' }
    themeOverride: null,          // { mode: 'day'|'night', period } set by the sun/moon button, like the app
  };
  const LEVELS = ['gentle', 'balanced', 'protective'];
  const MOODS = ['heavy', 'low', 'okay', 'good', 'bright'];

  const dayKey = (d) => { d = d || new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

  function merge(s) {
    s = s || {};
    return Object.assign({}, DEFAULTS, s, { categories: Object.assign({}, DEFAULTS.categories, s.categories || {}) });
  }
  async function load() { const r = await MS.store.get(['ms_settings']); return merge(r.ms_settings); }
  async function save(patch) {
    const cur = await load();
    const next = merge(Object.assign({}, cur, patch, { categories: Object.assign({}, cur.categories, (patch && patch.categories) || {}) }));
    await MS.store.set({ ms_settings: next });
    return next;
  }

  const moodToday = (s) => (s.mood && s.mood.date === dayKey() ? s.mood.value : null);
  function effectiveLevel(s) {
    const i = Math.max(0, LEVELS.indexOf(s.level));
    const m = moodToday(s);
    if (s.adaptToMood && (m === 'heavy' || m === 'low') && i < 2) return { level: LEVELS[i + 1], raised: true };
    return { level: LEVELS[i], raised: false };
  }
  function siteOf(url) { try { const u = new URL(url); return /^https?:$/.test(u.protocol) ? u.hostname.replace(/^www\./, '') : ''; } catch (e) { return ''; } }
  const isPaused = (s, host) => !!host && s.pausedSites.some((p) => host === p || host.endsWith('.' + p));
  const isBlocked = (s, host) => !!host && (s.blockedSites || []).some((p) => host === p || host.endsWith('.' + p));
  // "https://www.Reddit.com/r/x" or "reddit.com" -> "reddit.com"
  const cleanSite = (raw) => siteOf(/^https?:\/\//i.test(String(raw || '').trim()) ? String(raw).trim() : 'https://' + String(raw || '').trim()).toLowerCase();

  // Statistics: { 'YYYY-MM-DD': { total, cats: { suicide: n, ... } } }, last 14 days only
  async function loadStats() { const r = await MS.store.get(['ms_stats']); return r.ms_stats || {}; }
  async function addStats(delta) {
    const stats = await loadStats();
    const k = dayKey();
    const d = stats[k] || { total: 0, cats: {} };
    d.total += delta.total;
    Object.keys(delta.cats).forEach((c) => { d.cats[c] = (d.cats[c] || 0) + delta.cats[c]; });
    stats[k] = d;
    Object.keys(stats).sort().slice(0, -14).forEach((old) => delete stats[old]);
    await MS.store.set({ ms_stats: stats });
  }
  function lastDays(stats, n) {
    const out = [];
    for (let i = n - 1; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); const k = dayKey(d); out.push({ key: k, date: d, total: (stats[k] && stats[k].total) || 0, cats: (stats[k] && stats[k].cats) || {} }); }
    return out;
  }

  MS.settings = { DEFAULTS, LEVELS, MOODS, dayKey, merge, load, save, moodToday, effectiveLevel, siteOf, isPaused, isBlocked, cleanSite, loadStats, addStats, lastDays };
})();
