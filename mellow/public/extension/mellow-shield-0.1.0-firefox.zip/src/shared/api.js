/* Mellow Shield — one API for Chrome and Firefox (Manifest V3).
 * Uses `browser.*` (Firefox) or `chrome.*` (Chrome/Edge). Outside the extension
 * (UI preview in a normal tab) it falls back to localStorage so the pages still work. */
(function () {
  const g = globalThis;
  const MS = (g.MellowShield = g.MellowShield || {});
  const ext = (g.browser && g.browser.runtime && g.browser.storage) ? g.browser
    : (g.chrome && g.chrome.runtime && g.chrome.storage) ? g.chrome : null;
  MS.ext = ext;
  MS.isPreview = !ext;

  if (ext) {
    MS.store = {
      get: (keys) => ext.storage.local.get(keys),
      set: (obj) => ext.storage.local.set(obj),
      onChange: (fn) => ext.storage.onChanged.addListener((changes, area) => { if (area === 'local') fn(changes); }),
    };
    return;
  }

  const KEY = 'mellow-shield-preview';
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { return {}; } };
  const listeners = [];
  MS.store = {
    get: async (keys) => { const all = read(); const out = {}; [].concat(keys).forEach((k) => { if (k in all) out[k] = all[k]; }); return out; },
    set: async (obj) => {
      const all = read(); const changes = {};
      Object.keys(obj).forEach((k) => { changes[k] = { oldValue: all[k], newValue: obj[k] }; all[k] = obj[k]; });
      try { localStorage.setItem(KEY, JSON.stringify(all)); } catch (e) { /* private mode */ }
      listeners.forEach((fn) => fn(changes));
    },
    onChange: (fn) => {
      listeners.push(fn);
      g.addEventListener('storage', (e) => { if (e.key === KEY) fn({ ms_settings: {}, ms_stats: {} }); });
    },
  };
})();
