/* Mellow Shield — toolbar popup. */
(async function () {
  const MS = globalThis.MellowShield;
  const S = MS.settings;
  const { t } = MS.i18n;
  const $ = (id) => document.getElementById(id);

  let settings = await S.load();
  MS.i18n.setLang(settings.lang);
  MS.i18n.apply();
  MS.theme.apply(MS.theme.resolve(settings));

  // ---------- current site ----------
  let site = '';
  if (MS.ext && MS.ext.tabs) {
    try {
      const [tab] = await MS.ext.tabs.query({ active: true, currentWindow: true });
      const url = (tab && tab.url) || '';
      // on the Mellow page of a blocked site, the site is the blocked one
      site = url.startsWith(MS.ext.runtime.getURL('src/blocked/blocked.html')) ? S.cleanSite(new URL(url).searchParams.get('site') || '') : S.siteOf(url);
    } catch (e) { site = ''; }
  } else {
    site = 'example.com'; // UI preview outside the extension
  }

  // ---------- site access (Firefox can ask the user to grant it) ----------
  if (MS.ext && MS.ext.permissions && MS.ext.permissions.contains) {
    try {
      $('perm').hidden = await MS.ext.permissions.contains({ origins: ['<all_urls>'] });
      $('permBtn').addEventListener('click', async () => { $('perm').hidden = await MS.ext.permissions.request({ origins: ['<all_urls>'] }); });
    } catch (e) { /* not supported */ }
  }

  function renderHead() {
    const mood = S.moodToday(settings);
    $('brandMallow').innerHTML = MS.art.mallowSVG({ face: mood ? MS.art.MOOD_FACE[mood] : 'happy', size: 40 });
    const day = MS.theme.apply(MS.theme.resolve(settings)) === 'day';
    $('themeBtn').innerHTML = MS.art.iconSVG(day ? 'moon' : 'sun', { size: 18, color: day ? '#FFFFFF' : '#FFD36B' });
    $('themeBtn').setAttribute('aria-label', t(day ? 'theme_to_night' : 'theme_to_day'));
    $('themeBtn').title = t(day ? 'theme_to_night' : 'theme_to_day');
    $('enabled').checked = settings.enabled;
    const paused = site && S.isPaused(settings, site);
    const status = $('status');
    status.textContent = !settings.enabled ? t('status_off') : paused ? t('status_paused') : t('status_on');
    status.classList.toggle('off', !settings.enabled || !!paused);
    document.body.classList.toggle('off', !settings.enabled);
  }

  function renderSite() {
    const line = $('siteLine');
    const btn = $('siteToggle');
    $('siteBlock').hidden = !site || S.isBlocked(settings, site);
    if (!site) { line.textContent = t('no_site'); btn.hidden = true; return; }
    if (S.isBlocked(settings, site)) { line.textContent = t('blocked_on', { site }); btn.hidden = true; return; }
    const paused = S.isPaused(settings, site);
    line.textContent = t(paused ? 'site_paused' : 'site_on', { site });
    line.title = site;
    btn.hidden = false;
    btn.textContent = paused ? t('resume_site') : t('pause_site');
  }

  function renderMoods() {
    const box = $('moods');
    const current = S.moodToday(settings);
    box.innerHTML = '';
    S.MOODS.forEach((m) => {
      const b = document.createElement('button');
      b.className = 'mood';
      b.type = 'button';
      b.setAttribute('aria-pressed', String(current === m));
      b.innerHTML = MS.art.mallowSVG({ face: MS.art.MOOD_FACE[m], size: 30 });
      const label = document.createElement('span');
      label.textContent = t('mood_' + m);
      b.appendChild(label);
      b.addEventListener('click', async () => { settings = await S.save({ mood: { value: m, date: S.dayKey() } }); renderAll(); });
      box.appendChild(b);
    });
    const reply = $('moodReply');
    reply.hidden = !current;
    if (current) reply.textContent = t('reply_' + current);
  }

  let levelSeg = null;
  function renderLevels() {
    if (!levelSeg) {
      levelSeg = MS.ui.segmented($('levels'), S.LEVELS.map((l) => ({ value: l, label: t('level_' + l) })), settings.level,
        async (v) => { settings = await S.save({ level: v }); renderAll(); });
    } else levelSeg.set(settings.level);
    const eff = S.effectiveLevel(settings);
    $('levelNote').textContent = eff.raised ? t('raised_note', { level: t('level_' + eff.level) }) : t('level_desc_' + settings.level);
  }

  async function renderStats() {
    const days = S.lastDays(await S.loadStats(), 7);
    const today = days[days.length - 1];
    const n = today.total;
    $('todayNum').textContent = String(n);
    $('todayLabel').textContent = t(n === 0 ? 'count_none' : n === 1 ? 'count_one' : 'count_many');
    const week = days.reduce((a, d) => a + d.total, 0);
    // one line: the week, then today's categories
    const cats = Object.entries(today.cats).sort((a, b) => b[1] - a[1]).map(([c, k]) => t('cat_' + c) + ' ' + k);
    $('weekText').textContent = [week ? t('week', { n: week }) : ''].concat(cats).filter(Boolean).join(' · ');
    $('weekText').title = $('weekText').textContent;
    // Pixel columns: each day is a stack of 4px blocks, so the chart reads like the sprites
    const max = Math.max(1, ...days.map((d) => d.total));
    const letters = t('weekdays').split(' ');
    const bars = $('weekBars');
    const names = $('weekDays');
    bars.innerHTML = '';
    names.innerHTML = '';
    days.forEach((d, i) => {
      const bar = document.createElement('span');
      if (d.total) bar.className = i === days.length - 1 ? 'is-today' : 'on';
      bar.style.height = (d.total ? Math.max(1, Math.round((d.total / max) * 7)) * 4 : 2) + 'px';
      bar.title = d.key + ': ' + d.total;
      bars.appendChild(bar);
      const name = document.createElement('span');
      name.textContent = letters[d.date.getDay()] || '';
      if (i === days.length - 1) name.className = 'is-today';
      names.appendChild(name);
    });
  }

  function renderAll() { renderHead(); renderSite(); renderMoods(); renderLevels(); renderStats(); }

  // ---------- events ----------
  $('enabled').addEventListener('change', async (e) => { settings = await S.save({ enabled: e.target.checked }); renderAll(); });
  $('themeBtn').addEventListener('click', async () => { settings = await S.save({ themeOverride: MS.theme.flip(settings) }); renderAll(); });
  $('siteToggle').addEventListener('click', async () => {
    const paused = S.isPaused(settings, site);
    const list = paused ? settings.pausedSites.filter((p) => !(site === p || site.endsWith('.' + p))) : settings.pausedSites.concat(site);
    settings = await S.save({ pausedSites: list });
    renderAll();
  });
  // Block the current site: the open tab switches to the Mellow page straight away (src/content/blocker.js)
  $('siteBlock').addEventListener('click', async () => {
    if (site && !S.isBlocked(settings, site)) settings = await S.save({ blockedSites: settings.blockedSites.concat(site) });
    if (!MS.isPreview) setTimeout(() => window.close(), 250);
    else renderAll();
  });
  MS.store.onChange((changes) => { if (changes.ms_stats) renderStats(); });

  // ---------- settings, inside the popup ----------
  const CATS = ['suicide', 'hopeless', 'selfworth', 'hostile', 'news'];
  const DOTS = { suicide: 'var(--rose)', hopeless: 'var(--sky)', selfworth: 'var(--green)', hostile: 'var(--fire)', news: 'var(--muted)' };
  const MODES = ['blur', 'hide', 'warn'];
  let modeSeg = null;
  let toastTimer = null;
  function toast(msg) {
    const el = $('toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 1400);
  }
  async function update(patch, quiet) {
    settings = await S.save(patch);
    renderSettings();
    if (!quiet) toast(t('toast_saved'));
  }
  let tabSeg = null;
  let tab = 'filter';
  function showTab(name) {
    tab = name;
    document.querySelectorAll('#settingsView .panel').forEach((p) => { p.hidden = p.dataset.panel !== name; });
  }
  function renderSettings() {
    // same header as the main view: today's marshmallow and the on/off/paused line
    const mood = S.moodToday(settings);
    $('setMallow').innerHTML = MS.art.mallowSVG({ face: mood ? MS.art.MOOD_FACE[mood] : 'happy', size: 40 });
    $('setStatus').textContent = $('status').textContent;
    if (!tabSeg) tabSeg = MS.ui.segmented($('setTabs'), ['filter', 'sites', 'more'].map((v) => ({ value: v, label: t('tab_' + v) })), tab, showTab);
    showTab(tab);
    if (!modeSeg) {
      modeSeg = MS.ui.segmented($('modes'), MODES.map((m) => ({ value: m, label: t('mode_' + m) })), settings.mode,
        (v) => { $('modeDesc').textContent = t('modedesc_' + v); update({ mode: v }); });
    } else modeSeg.set(settings.mode);
    $('modeDesc').textContent = t('modedesc_' + settings.mode);
    $('adapt').checked = settings.adaptToMood;

    const box = $('cats');
    box.innerHTML = '';
    CATS.forEach((c) => {
      const row = document.createElement('label');
      row.className = 'cat' + (settings.categories[c] ? '' : ' off');
      row.style.setProperty('--dot', DOTS[c]);
      const info = document.createElement('span'); info.className = 'cat-info';
      const name = document.createElement('span'); name.className = 'cat-name'; name.textContent = t('cat_' + c);
      const desc = document.createElement('span'); desc.className = 'sub'; desc.textContent = t('catdesc_' + c); row.title = t('catdesc_' + c);
      info.append(name, desc);
      const sw = document.createElement('span'); sw.className = 'switch';
      const input = document.createElement('input'); input.type = 'checkbox'; input.checked = !!settings.categories[c]; input.setAttribute('aria-label', t('cat_' + c));
      input.addEventListener('change', () => update({ categories: { [c]: input.checked } }));
      sw.append(input, document.createElement('span'));
      row.append(info, sw);
      box.appendChild(row);
    });

    if (document.activeElement !== $('customBlock')) $('customBlock').value = settings.customBlock.join('\n');
    if (document.activeElement !== $('customAllow')) $('customAllow').value = settings.customAllow.join('\n');
    siteList('sites', 'pausedSites', 'sites_empty');
    siteList('blocked', 'blockedSites', 'block_empty');
    test();
  }
  function siteList(id, key, emptyKey) {
    const list = $(id);
    list.innerHTML = '';
    if (!settings[key].length) { const li = document.createElement('li'); li.className = 'empty sub'; li.textContent = t(emptyKey); list.appendChild(li); }
    settings[key].forEach((s) => {
      const li = document.createElement('li');
      const name = document.createElement('span'); name.textContent = s;
      const rm = document.createElement('button'); rm.className = 'link'; rm.type = 'button'; rm.textContent = t('remove');
      rm.addEventListener('click', () => update({ [key]: settings[key].filter((x) => x !== s) }));
      li.append(name, rm);
      list.appendChild(li);
    });
  }
  function test() {
    const text = $('testInput').value;
    const out = $('testResult');
    if (!text.trim()) { out.textContent = ''; out.className = 'test-result'; return; }
    const eff = S.effectiveLevel(settings);
    const res = MS.classify(text, { level: eff.level, categories: settings.categories, customBlock: settings.customBlock, customAllow: settings.customAllow });
    out.textContent = res.flag ? t('result_flag') + ' · ' + t('cat_' + res.category) : t('result_ok');
    out.className = 'test-result ' + (res.flag ? 'is-flag' : 'is-ok');
  }
  function openSettings() {
    $('main').hidden = true;
    $('settingsView').hidden = false;
    renderSettings();
    window.scrollTo(0, 0);
    $('backBtn').focus();
  }
  function closeSettings() { $('settingsView').hidden = true; $('main').hidden = false; window.scrollTo(0, 0); renderAll(); }

  $('optionsBtn').addEventListener('click', openSettings);
  $('backBtn').addEventListener('click', closeSettings);
  $('adapt').addEventListener('change', (e) => update({ adaptToMood: e.target.checked }));
  let typing = null;
  $('testInput').addEventListener('input', () => { clearTimeout(typing); typing = setTimeout(test, 150); });
  const lines = (id) => $(id).value.split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 200);
  $('saveWords').addEventListener('click', () => update({ customBlock: lines('customBlock'), customAllow: lines('customAllow') }));
  const adder = (inputId, btnId, key) => {
    const add = () => {
      const h = S.cleanSite($(inputId).value);
      if (h && h.includes('.') && !settings[key].includes(h)) update({ [key]: settings[key].concat(h) });
      $(inputId).value = '';
    };
    $(btnId).addEventListener('click', add);
    $(inputId).addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
  };
  adder('siteInput', 'addSite', 'pausedSites');
  adder('blockInput', 'addBlock', 'blockedSites');
  $('resetStats').addEventListener('click', async () => { await MS.store.set({ ms_stats: {} }); renderStats(); toast(t('stats_cleared')); });

  // ---------- breathe (4 in, 3 hold, 6 out, three times) ----------
  // A timer ring around the fire, like a phone timer: it closes while you breathe in,
  // stays closed while you hold, and opens again while you breathe out.
  const PHASES = [['breathe_in', 4000, 1.35, 'fill'], ['breathe_hold', 3000, 1.35, 'hold'], ['breathe_out', 6000, 0.85, 'empty']];
  const RING = 2 * Math.PI * 88; // circumference of the ring (r = 88 in a 200 viewBox)
  let timer = null;
  let ticker = null;
  const flame = $('flame');
  const ring = $('ringProgress');
  const stage = $('breathStage');
  // Sized so that even at its biggest (scale 1.35) the fire's corners stay inside the ring:
  // 68 x 85 px -> half-diagonal 54 px -> 73 px when scaled, under the ring's inner radius (~83 px)
  flame.innerHTML = MS.art.flameSVG({ size: 68 });
  ring.style.strokeDasharray = RING + ' ' + RING;

  function setRing(offset, ms, visible) {
    ring.style.transition = 'stroke-dashoffset ' + ms + 'ms linear, opacity .3s, stroke .5s';
    ring.style.strokeDashoffset = String(offset);
    if (visible !== undefined) ring.style.opacity = visible ? '1' : '0';
  }
  function countdown(ms) {
    clearInterval(ticker);
    let left = Math.round(ms / 1000);
    $('breathSecs').textContent = String(left);
    ticker = setInterval(() => { left -= 1; $('breathSecs').textContent = left > 0 ? String(left) : ''; if (left <= 0) clearInterval(ticker); }, 1000);
  }
  const setPhase = (title, sub) => { $('breathPhase').textContent = title; $('breathSub').textContent = sub; };
  function resetBreathe() {
    clearTimeout(timer);
    clearInterval(ticker);
    stage.classList.remove('is-holding');
    setRing(RING, 0, false);
    $('breathSecs').textContent = '';
    flame.style.transitionDuration = '400ms';
    flame.style.transform = 'scale(1)';
  }
  function openBreathe() {
    $('main').hidden = true;
    $('breathe').hidden = false;
    $('breathStart').hidden = false;
    resetBreathe();
    setPhase(t('breathe_btn'), t('breathe_ready'));
    $('breathStart').focus();
  }
  function closeBreathe() { resetBreathe(); $('breathe').hidden = true; $('main').hidden = false; }
  function run(cycle, step) {
    if (cycle >= 3) {
      stage.classList.remove('is-holding');
      setRing(RING, 0, false);
      $('breathSecs').textContent = '';
      flame.style.transitionDuration = '600ms';
      flame.style.transform = 'scale(1)';
      setPhase(t('breathe_done'), '');
      return;
    }
    const [key, ms, scale, ringMove] = PHASES[step];
    flame.style.transitionDuration = ms + 'ms';
    flame.style.transform = 'scale(' + scale + ')';
    stage.classList.toggle('is-holding', ringMove === 'hold');
    if (ringMove === 'fill') { setRing(RING, 0, true); void ring.getBoundingClientRect(); setRing(0, ms, true); }
    if (ringMove === 'empty') setRing(RING, ms, true);
    countdown(ms);
    setPhase(t(key), t('breathe_count', { n: cycle + 1 }));
    timer = setTimeout(() => (step < 2 ? run(cycle, step + 1) : run(cycle + 1, 0)), ms);
  }
  $('breatheBtn').addEventListener('click', openBreathe);
  $('breathClose').addEventListener('click', closeBreathe);
  $('breathStart').addEventListener('click', () => { $('breathStart').hidden = true; run(0, 0); });

  renderAll();
})();
