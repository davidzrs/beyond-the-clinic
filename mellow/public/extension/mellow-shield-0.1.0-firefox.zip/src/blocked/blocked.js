/* Mellow Shield — the page shown instead of a blocked site. */
(async function () {
  const MS = globalThis.MellowShield;
  const S = MS.settings;
  const { t } = MS.i18n;
  const $ = (id) => document.getElementById(id);

  const settings = await S.load();
  MS.i18n.setLang(settings.lang);
  MS.i18n.apply();
  MS.theme.apply(MS.theme.resolve(settings));

  const site = S.cleanSite(new URLSearchParams(location.search).get('site') || '') || 'example.com';
  // The address that was blocked comes last and unencoded ("&url=https://..."), exactly as the browser asked for it.
  // Only used if it really is on the blocked site, so this page can't be used to send anyone elsewhere.
  const asked = (() => {
    const i = location.search.indexOf('&url=');
    const raw = i >= 0 ? location.search.slice(i + 5) : '';
    try { const u = new URL(raw); if (/^https?:$/.test(u.protocol) && S.cleanSite(u.href) && (S.cleanSite(u.href) === site || S.cleanSite(u.href).endsWith('.' + site))) return u.href; } catch (e) { /* none */ }
    return 'https://' + site + '/';
  })();
  // Open the site once it's no longer blocked (after the browser rule is gone, or it would bounce straight back here)
  let leaving = false;
  async function openSite() {
    if (leaving || MS.isPreview) return;
    leaving = true;
    const dnr = MS.ext && MS.ext.declarativeNetRequest;
    for (let i = 0; dnr && i < 30; i++) {
      const rules = await dnr.getDynamicRules();
      const mine = 'site=' + encodeURIComponent(site) + '&';
      if (!rules.some((r) => JSON.stringify(r.action).includes(mine) || (r.condition.requestDomains || []).includes(site))) break;
      await new Promise((ok) => setTimeout(ok, 100));
    }
    location.replace(asked);
  }
  // Unblocked somewhere else (popup, settings): reloading this page, or just waiting, takes you to the site
  // (also when the whole extension is switched off)
  const stillBlocked = (s) => s.enabled !== false && S.isBlocked(s, site);
  if (!stillBlocked(settings)) { openSite(); return; }
  MS.store.onChange(async (c) => { if (c.ms_settings && !stillBlocked(await S.load())) openSite(); });
  document.title = t('blocked_on', { site });
  $('mallow').innerHTML = MS.art.mallowSVG({ face: 'calm', size: 88 });

  // "{site}" in bold, without building HTML from the URL
  const lead = $('lead');
  const [before, after] = t('blocked_p').split('{site}');
  const b = document.createElement('b');
  b.textContent = site;
  lead.append(before || '', b, after || '');

  // Back: to the page before, or a blank tab when the blocked site was opened directly
  const back = $('backBtn');
  back.addEventListener('click', () => { if (history.length > 1) history.back(); else location.replace('about:blank'); });

  // Breathe with the marshmallow, like the popup: 4 s in, 3 s hold, 6 s out, three times,
  // with a timer ring around it and the seconds counting down
  const PHASES = [['breathe_in', 4000, 1.15, 'fill'], ['breathe_hold', 3000, 1.15, 'hold'], ['breathe_out', 6000, 0.95, 'empty']];
  const RING = 2 * Math.PI * 88;
  const mallow = $('mallow');
  const ring = $('ring');
  const stage = $('stage');
  const btn = $('breatheBtn');
  ring.style.strokeDasharray = RING + ' ' + RING;
  let timer = null;
  let ticker = null;
  let breathing = false;
  function setRing(offset, ms, visible) {
    ring.style.transition = 'stroke-dashoffset ' + ms + 'ms linear, opacity .3s, stroke .5s';
    ring.style.strokeDashoffset = String(offset);
    if (visible !== undefined) ring.style.opacity = visible ? '1' : '0';
  }
  function countdown(ms) {
    clearInterval(ticker);
    let left = Math.round(ms / 1000);
    $('breathSecs').textContent = String(left);
    ticker = setInterval(() => { left -= 1; $('breathSecs').textContent = left > 0 ? String(left) : ''; if (left <= 0) clearInterval(ticker); }, 1000);
  }
  function stopBreathing(doneText) {
    clearTimeout(timer);
    clearInterval(ticker);
    breathing = false;
    stage.classList.remove('is-on', 'is-holding');
    setRing(RING, 0, false);
    mallow.style.transitionDuration = '600ms';
    mallow.style.transform = '';
    $('breathSecs').textContent = '';
    $('breathText').textContent = doneText || '';
    btn.textContent = t('blocked_breathe');
  }
  function run(cycle, step) {
    if (cycle >= 3) { stopBreathing(t('breathe_done')); return; }
    const [key, ms, scale, move] = PHASES[step];
    mallow.style.transitionDuration = ms + 'ms';
    mallow.style.transform = 'scale(' + scale + ')';
    stage.classList.toggle('is-holding', move === 'hold');
    if (move === 'fill') { setRing(RING, 0, true); void ring.getBoundingClientRect(); setRing(0, ms, true); }
    if (move === 'empty') setRing(RING, ms, true);
    countdown(ms);
    $('breathText').textContent = t(key) + ' · ' + t('breathe_count', { n: cycle + 1 });
    timer = setTimeout(() => (step < 2 ? run(cycle, step + 1) : run(cycle + 1, 0)), ms);
  }
  setRing(RING, 0, false);
  btn.addEventListener('click', () => {
    if (breathing) { stopBreathing(); return; }
    breathing = true;
    stage.classList.add('is-on');
    btn.textContent = t('close');
    run(0, 0);
  });

  // Unblocking takes a ten-second pause first, so it's a choice and not a reflex
  const unblock = $('unblockBtn');
  const note = $('unblockNote');
  let ready = false;
  unblock.addEventListener('click', async () => {
    if (ready) {
      await S.save({ blockedSites: (await S.load()).blockedSites.filter((x) => x !== site) });
      openSite();
      return;
    }
    if (unblock.disabled) return;
    unblock.disabled = true;
    note.hidden = false;
    note.textContent = t('blocked_note', { site });
    let n = 10;
    const tick = () => {
      if (n <= 0) { unblock.disabled = false; ready = true; unblock.textContent = t('blocked_sure'); unblock.classList.add('is-ready'); return; }
      unblock.textContent = t('blocked_wait', { n });
      n -= 1;
      setTimeout(tick, 1000);
    };
    tick();
  });
})();
